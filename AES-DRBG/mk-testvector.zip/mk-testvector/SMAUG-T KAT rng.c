﻿
#define _CRT_SECURE_NO_WARNINGS


#include "rng.h"
#include <fcntl.h>
#include <openssl/conf.h>
#include <openssl/err.h>
#include <openssl/evp.h>
#include <string.h>
#include "parameter.h"
#include <io.h>



#define MAX_MARKER_LEN 50
#define KAT_SUCCESS 0
#define KAT_FILE_OPEN_ERROR -1
#define KAT_DATA_ERROR -3
#define KAT_CRYPTO_FAILURE -4

AES256_CTR_DRBG_struct DRBG_ctx;

void AES256_ECB(unsigned char* key, unsigned char* ctr, unsigned char* buffer);

/*
 seedexpander_init()
 ctx            - stores the current state of an instance of the seed expander
 seed           - a 32 byte random value
 diversifier    - an 8 byte diversifier
 maxlen         - maximum number of bytes (less than 2**32) generated under this
 seed and diversifier
 */
int seedexpander_init(AES_XOF_struct* ctx, unsigned char* seed,
    unsigned char* diversifier, unsigned long maxlen) {
    if (maxlen >= 0x100000000)
        return RNG_BAD_MAXLEN;

    ctx->length_remaining = maxlen;

    memcpy(ctx->key, seed, 32);

    memcpy(ctx->ctr, diversifier, 8);
    ctx->ctr[11] = maxlen % 256;
    maxlen >>= 8;
    ctx->ctr[10] = maxlen % 256;
    maxlen >>= 8;
    ctx->ctr[9] = maxlen % 256;
    maxlen >>= 8;
    ctx->ctr[8] = maxlen % 256;
    memset(ctx->ctr + 12, 0x00, 4);

    ctx->buffer_pos = 16;
    memset(ctx->buffer, 0x00, 16);

    return RNG_SUCCESS;
}

/*
 seedexpander()
    ctx  - stores the current state of an instance of the seed expander
    x    - returns the XOF data
    xlen - number of bytes to return
 */
int seedexpander(AES_XOF_struct* ctx, unsigned char* x, unsigned long xlen) {
    unsigned long offset;

    if (x == NULL)
        return RNG_BAD_OUTBUF;
    if (xlen >= ctx->length_remaining)
        return RNG_BAD_REQ_LEN;

    ctx->length_remaining -= xlen;

    offset = 0;
    while (xlen > 0) {
        if (xlen <= (16 - ctx->buffer_pos)) { // buffer has what we need
            memcpy(x + offset, ctx->buffer + ctx->buffer_pos, xlen);
            ctx->buffer_pos += xlen;

            return RNG_SUCCESS;
        }

        // take what's in the buffer
        memcpy(x + offset, ctx->buffer + ctx->buffer_pos, 16 - ctx->buffer_pos);
        xlen -= 16 - ctx->buffer_pos;
        offset += 16 - ctx->buffer_pos;

        AES256_ECB(ctx->key, ctx->ctr, ctx->buffer);
        ctx->buffer_pos = 0;

        // increment the counter
        for (int i = 15; i >= 12; i--) {
            if (ctx->ctr[i] == 0xff)
                ctx->ctr[i] = 0x00;
            else {
                ctx->ctr[i]++;
                break;
            }
        }
    }

    return RNG_SUCCESS;
}

void handleErrors(void) {
    ERR_print_errors_fp(stderr);
    abort();
}

// Use whatever AES implementation you have. This uses AES from openSSL library
//    key - 256-bit AES key
//    ctr - a 128-bit plaintext value
//    buffer - a 128-bit ciphertext value
void AES256_ECB(unsigned char* key, unsigned char* ctr, unsigned char* buffer) {
    EVP_CIPHER_CTX* ctx;

    int len;

    /* Create and initialise the context */
    if (!(ctx = EVP_CIPHER_CTX_new()))
        handleErrors();

    if (1 != EVP_EncryptInit_ex(ctx, EVP_aes_256_ecb(), NULL, key, NULL))
        handleErrors();

    if (1 != EVP_EncryptUpdate(ctx, buffer, &len, ctr, 16))
        handleErrors();

    /* Clean up */
    EVP_CIPHER_CTX_free(ctx);
}

void randombytes_init(unsigned char* entropy_input,
    unsigned char* personalization_string,
    int security_strength) {
    unsigned char seed_material[48];

    memcpy(seed_material, entropy_input, 48);
    if (personalization_string)
        for (int i = 0; i < 48; i++)
            seed_material[i] ^= personalization_string[i];
    memset(DRBG_ctx.Key, 0x00, 32);
    memset(DRBG_ctx.V, 0x00, 16);
    AES256_CTR_DRBG_Update(seed_material, DRBG_ctx.Key, DRBG_ctx.V);
    DRBG_ctx.reseed_counter = 1;
    DRBG_ctx.init = 1;
}


int randombytes(unsigned char* x, unsigned long long xlen) {
    unsigned char block[16];
    int i = 0;

    // Initialize generator
    if (!DRBG_ctx.init) {
        int fd;
        fd = fopen("PQCkemKAT_832.req", 0);
        uint8_t entropy_input[48];
        if (fd < 0) {
            // Random source is not supplied
            for (int i = 0; i < 48; i++)
                entropy_input[i] = i;
        }
        else {
            int result = fgets(entropy_input, 48, fd);
            if (result < 0) {
                printf("Random generation failed.\n");
            }
        }
        fclose(fd);

        randombytes_init(entropy_input, NULL, 256);
    }

    while (xlen > 0) {
        // increment V
        for (int j = 15; j >= 0; j--) {
            if (DRBG_ctx.V[j] == 0xff)
                DRBG_ctx.V[j] = 0x00;
            else {
                DRBG_ctx.V[j]++;
                break;
            }
        }
        AES256_ECB(DRBG_ctx.Key, DRBG_ctx.V, block);
        if (xlen > 15) {
            memcpy(x + i, block, 16);
            i += 16;
            xlen -= 16;
        }
        else {
            memcpy(x + i, block, xlen);
            xlen = 0;
        }
    }
    AES256_CTR_DRBG_Update(NULL, DRBG_ctx.Key, DRBG_ctx.V);
    DRBG_ctx.reseed_counter++;

    return RNG_SUCCESS;
}

void AES256_CTR_DRBG_Update(unsigned char* provided_data, unsigned char* Key,
    unsigned char* V) {
    unsigned char temp[48];

    for (int i = 0; i < 3; i++) {
        // increment V
        for (int j = 15; j >= 0; j--) {
            if (V[j] == 0xff)
                V[j] = 0x00;
            else {
                V[j]++;
                break;
            }
        }

        AES256_ECB(Key, V, temp + 16 * i);
    }
    if (provided_data != NULL)
        for (int i = 0; i < 48; i++)
            temp[i] ^= provided_data[i];
    memcpy(Key, temp, 32);
    memcpy(V, temp + 32, 16);
}



//
// ALLOW TO READ HEXADECIMAL ENTRY (KEYS, DATA, TEXT, etc.)
//
//
// ALLOW TO READ HEXADECIMAL ENTRY (KEYS, DATA, TEXT, etc.)
//
int FindMarker(FILE* infile, const char* marker) {
    char line[MAX_MARKER_LEN];
    int i, len;
    int curr_line;

    len = (int)strlen(marker);
    if (len > MAX_MARKER_LEN - 1)
        len = MAX_MARKER_LEN - 1;

    for (i = 0; i < len; i++) {
        curr_line = fgetc(infile);
        line[i] = curr_line;
        if (curr_line == EOF)
            return 0;
    }
    line[len] = '\0';

    while (1) {
        if (!strncmp(line, marker, len))
            return 1;

        for (i = 0; i < len - 1; i++)
            line[i] = line[i + 1];
        curr_line = fgetc(infile);
        line[len - 1] = curr_line;
        if (curr_line == EOF)
            return 0;
        line[len] = '\0';
    }

    // shouldn't get here
    return 0;
}

//
// ALLOW TO READ HEXADECIMAL ENTRY (KEYS, DATA, TEXT, etc.)
//
int ReadHex(FILE* infile, unsigned char* A, int Length, char* str) {
    int i, ch, started;
    unsigned char ich;

    if (Length == 0) {
        A[0] = 0x00;
        return 1;
    }
    memset(A, 0x00, Length);
    started = 0;
    if (FindMarker(infile, str))
        while ((ch = fgetc(infile)) != EOF) {
            if (!isxdigit(ch)) {
                if (!started) {
                    if (ch == '\n')
                        break;
                    else
                        continue;
                }
                else
                    break;
            }
            started = 1;
            if ((ch >= '0') && (ch <= '9'))
                ich = ch - '0';
            else if ((ch >= 'A') && (ch <= 'F'))
                ich = ch - 'A' + 10;
            else if ((ch >= 'a') && (ch <= 'f'))
                ich = ch - 'a' + 10;
            else // shouldn't ever get here
                ich = 0;

            for (i = 0; i < Length - 1; i++)
                A[i] = (A[i] << 4) | (A[i + 1] >> 4);
            A[Length - 1] = (A[Length - 1] << 4) | ich;
        }
    else
        return 0;

    return 1;
}

void fprintBstr(FILE* fp, char* S, unsigned char* A, unsigned long long L) {
    unsigned long long i;

    fprintf(fp, "%s", S);

    for (i = 0; i < L; i++)
        fprintf(fp, "%02X", A[i]);

    if (L == 0)
        fprintf(fp, "00");

    fprintf(fp, "\n");
}



#include <stddef.h>
#include <stdint.h>

#include <stdlib.h>
#include "fips202.h"


#define NROUNDS 24
#define ROL(a, offset) ((a << offset) ^ (a >> (64 - offset)))

#define SCHB_N 16

#define N_RES (LWE_N << 1)
#define N_SB (LWE_N >> 2)       // LWE_N : 256 = 2^8 -> 2^6
#define N_SB_RES (2 * N_SB - 1)

#define OVERFLOWING_MUL(X, Y) ((uint16_t)((uint32_t)(X) * (uint32_t)(Y)))

#define KARATSUBA_N 64

#define NTT_Q (8380417)
#define NTT_QINV 58728449	 // q^(-1) mod 2^32




static uint64_t load64(const uint8_t x[8]) {
    unsigned int i;
    uint64_t r = 0;

    for (i = 0; i < 8; i++)
        r |= (uint64_t)x[i] << 8 * i;

    return r;
}

static void store64(uint8_t x[8], uint64_t u) {
    unsigned int i;

    for (i = 0; i < 8; i++)
        x[i] = u >> 8 * i;
}

static void load16_littleendian(int16_t* out, const int outlen,
    const uint8_t* in) {
    int pos = 0;
    for (int i = 0; i < outlen; ++i) {
        out[i] = ((int16_t)(in[pos])) | ((int16_t)(in[pos + 1]) << 8);
        pos += 2;
    }
}

static void store16_littleendian(uint8_t* out, const int16_t* in,
    const int inlen) {
    int pos = 0;
    for (int i = 0; i < inlen; ++i) {
        out[pos] = in[i];
        out[pos + 1] = in[i] >> 8;
        pos += 2;
    }
}

static uint32_t load24_littleendian(const uint8_t x[3]) {
    uint32_t r;
    r = (uint32_t)x[0];
    r |= (uint32_t)x[1] << 8;
    r |= (uint32_t)x[2] << 16;
    return r;
}
static uint32_t load32_littleendian(const uint8_t x[4]) {
    uint32_t r;
    r = (uint32_t)x[0];
    r |= (uint32_t)x[1] << 8;
    r |= (uint32_t)x[2] << 16;
    r |= (uint32_t)x[3] << 24;
    return r;
}

static void load64_littleendian(uint64_t* out, const unsigned int outlen,
    const uint8_t* in) {
    unsigned int i, pos = 0;
    for (i = 0; i < outlen; ++i) {
        out[i] =
            ((uint64_t)(in[pos])) | ((uint64_t)(in[pos + 1]) << 8) |
            ((uint64_t)(in[pos + 2]) << 16) | ((uint64_t)(in[pos + 3]) << 24) |
            ((uint64_t)(in[pos + 4]) << 32) | ((uint64_t)(in[pos + 5]) << 40) |
            ((uint64_t)(in[pos + 6]) << 48) | ((uint64_t)(in[pos + 7]) << 56);
        pos += 8;
    }
}


/* Keccak round constants */
const uint64_t KeccakF_RoundConstants[NROUNDS] = {
    (uint64_t)0x0000000000000001ULL, (uint64_t)0x0000000000008082ULL,
    (uint64_t)0x800000000000808aULL, (uint64_t)0x8000000080008000ULL,
    (uint64_t)0x000000000000808bULL, (uint64_t)0x0000000080000001ULL,
    (uint64_t)0x8000000080008081ULL, (uint64_t)0x8000000000008009ULL,
    (uint64_t)0x000000000000008aULL, (uint64_t)0x0000000000000088ULL,
    (uint64_t)0x0000000080008009ULL, (uint64_t)0x000000008000000aULL,
    (uint64_t)0x000000008000808bULL, (uint64_t)0x800000000000008bULL,
    (uint64_t)0x8000000000008089ULL, (uint64_t)0x8000000000008003ULL,
    (uint64_t)0x8000000000008002ULL, (uint64_t)0x8000000000000080ULL,
    (uint64_t)0x000000000000800aULL, (uint64_t)0x800000008000000aULL,
    (uint64_t)0x8000000080008081ULL, (uint64_t)0x8000000000008080ULL,
    (uint64_t)0x0000000080000001ULL, (uint64_t)0x8000000080008008ULL };

static void KeccakF1600_StatePermute(uint64_t state[25]) {
    int round;

    uint64_t Aba, Abe, Abi, Abo, Abu;
    uint64_t Aga, Age, Agi, Ago, Agu;
    uint64_t Aka, Ake, Aki, Ako, Aku;
    uint64_t Ama, Ame, Ami, Amo, Amu;
    uint64_t Asa, Ase, Asi, Aso, Asu;
    uint64_t BCa, BCe, BCi, BCo, BCu;
    uint64_t Da, De, Di, Do, Du;
    uint64_t Eba, Ebe, Ebi, Ebo, Ebu;
    uint64_t Ega, Ege, Egi, Ego, Egu;
    uint64_t Eka, Eke, Eki, Eko, Eku;
    uint64_t Ema, Eme, Emi, Emo, Emu;
    uint64_t Esa, Ese, Esi, Eso, Esu;

    // copyFromState(A, state)
    Aba = state[0];
    Abe = state[1];
    Abi = state[2];
    Abo = state[3];
    Abu = state[4];
    Aga = state[5];
    Age = state[6];
    Agi = state[7];
    Ago = state[8];
    Agu = state[9];
    Aka = state[10];
    Ake = state[11];
    Aki = state[12];
    Ako = state[13];
    Aku = state[14];
    Ama = state[15];
    Ame = state[16];
    Ami = state[17];
    Amo = state[18];
    Amu = state[19];
    Asa = state[20];
    Ase = state[21];
    Asi = state[22];
    Aso = state[23];
    Asu = state[24];

    for (round = 0; round < NROUNDS; round += 2) {
        //    prepareTheta
        BCa = Aba ^ Aga ^ Aka ^ Ama ^ Asa;
        BCe = Abe ^ Age ^ Ake ^ Ame ^ Ase;
        BCi = Abi ^ Agi ^ Aki ^ Ami ^ Asi;
        BCo = Abo ^ Ago ^ Ako ^ Amo ^ Aso;
        BCu = Abu ^ Agu ^ Aku ^ Amu ^ Asu;

        // thetaRhoPiChiIotaPrepareTheta(round, A, E)
        Da = BCu ^ ROL(BCe, 1);
        De = BCa ^ ROL(BCi, 1);
        Di = BCe ^ ROL(BCo, 1);
        Do = BCi ^ ROL(BCu, 1);
        Du = BCo ^ ROL(BCa, 1);

        Aba ^= Da;
        BCa = Aba;
        Age ^= De;
        BCe = ROL(Age, 44);
        Aki ^= Di;
        BCi = ROL(Aki, 43);
        Amo ^= Do;
        BCo = ROL(Amo, 21);
        Asu ^= Du;
        BCu = ROL(Asu, 14);
        Eba = BCa ^ ((~BCe) & BCi);
        Eba ^= (uint64_t)KeccakF_RoundConstants[round];
        Ebe = BCe ^ ((~BCi) & BCo);
        Ebi = BCi ^ ((~BCo) & BCu);
        Ebo = BCo ^ ((~BCu) & BCa);
        Ebu = BCu ^ ((~BCa) & BCe);

        Abo ^= Do;
        BCa = ROL(Abo, 28);
        Agu ^= Du;
        BCe = ROL(Agu, 20);
        Aka ^= Da;
        BCi = ROL(Aka, 3);
        Ame ^= De;
        BCo = ROL(Ame, 45);
        Asi ^= Di;
        BCu = ROL(Asi, 61);
        Ega = BCa ^ ((~BCe) & BCi);
        Ege = BCe ^ ((~BCi) & BCo);
        Egi = BCi ^ ((~BCo) & BCu);
        Ego = BCo ^ ((~BCu) & BCa);
        Egu = BCu ^ ((~BCa) & BCe);

        Abe ^= De;
        BCa = ROL(Abe, 1);
        Agi ^= Di;
        BCe = ROL(Agi, 6);
        Ako ^= Do;
        BCi = ROL(Ako, 25);
        Amu ^= Du;
        BCo = ROL(Amu, 8);
        Asa ^= Da;
        BCu = ROL(Asa, 18);
        Eka = BCa ^ ((~BCe) & BCi);
        Eke = BCe ^ ((~BCi) & BCo);
        Eki = BCi ^ ((~BCo) & BCu);
        Eko = BCo ^ ((~BCu) & BCa);
        Eku = BCu ^ ((~BCa) & BCe);

        Abu ^= Du;
        BCa = ROL(Abu, 27);
        Aga ^= Da;
        BCe = ROL(Aga, 36);
        Ake ^= De;
        BCi = ROL(Ake, 10);
        Ami ^= Di;
        BCo = ROL(Ami, 15);
        Aso ^= Do;
        BCu = ROL(Aso, 56);
        Ema = BCa ^ ((~BCe) & BCi);
        Eme = BCe ^ ((~BCi) & BCo);
        Emi = BCi ^ ((~BCo) & BCu);
        Emo = BCo ^ ((~BCu) & BCa);
        Emu = BCu ^ ((~BCa) & BCe);

        Abi ^= Di;
        BCa = ROL(Abi, 62);
        Ago ^= Do;
        BCe = ROL(Ago, 55);
        Aku ^= Du;
        BCi = ROL(Aku, 39);
        Ama ^= Da;
        BCo = ROL(Ama, 41);
        Ase ^= De;
        BCu = ROL(Ase, 2);
        Esa = BCa ^ ((~BCe) & BCi);
        Ese = BCe ^ ((~BCi) & BCo);
        Esi = BCi ^ ((~BCo) & BCu);
        Eso = BCo ^ ((~BCu) & BCa);
        Esu = BCu ^ ((~BCa) & BCe);

        //    prepareTheta
        BCa = Eba ^ Ega ^ Eka ^ Ema ^ Esa;
        BCe = Ebe ^ Ege ^ Eke ^ Eme ^ Ese;
        BCi = Ebi ^ Egi ^ Eki ^ Emi ^ Esi;
        BCo = Ebo ^ Ego ^ Eko ^ Emo ^ Eso;
        BCu = Ebu ^ Egu ^ Eku ^ Emu ^ Esu;

        // thetaRhoPiChiIotaPrepareTheta(round+1, E, A)
        Da = BCu ^ ROL(BCe, 1);
        De = BCa ^ ROL(BCi, 1);
        Di = BCe ^ ROL(BCo, 1);
        Do = BCi ^ ROL(BCu, 1);
        Du = BCo ^ ROL(BCa, 1);

        Eba ^= Da;
        BCa = Eba;
        Ege ^= De;
        BCe = ROL(Ege, 44);
        Eki ^= Di;
        BCi = ROL(Eki, 43);
        Emo ^= Do;
        BCo = ROL(Emo, 21);
        Esu ^= Du;
        BCu = ROL(Esu, 14);
        Aba = BCa ^ ((~BCe) & BCi);
        Aba ^= (uint64_t)KeccakF_RoundConstants[round + 1];
        Abe = BCe ^ ((~BCi) & BCo);
        Abi = BCi ^ ((~BCo) & BCu);
        Abo = BCo ^ ((~BCu) & BCa);
        Abu = BCu ^ ((~BCa) & BCe);

        Ebo ^= Do;
        BCa = ROL(Ebo, 28);
        Egu ^= Du;
        BCe = ROL(Egu, 20);
        Eka ^= Da;
        BCi = ROL(Eka, 3);
        Eme ^= De;
        BCo = ROL(Eme, 45);
        Esi ^= Di;
        BCu = ROL(Esi, 61);
        Aga = BCa ^ ((~BCe) & BCi);
        Age = BCe ^ ((~BCi) & BCo);
        Agi = BCi ^ ((~BCo) & BCu);
        Ago = BCo ^ ((~BCu) & BCa);
        Agu = BCu ^ ((~BCa) & BCe);

        Ebe ^= De;
        BCa = ROL(Ebe, 1);
        Egi ^= Di;
        BCe = ROL(Egi, 6);
        Eko ^= Do;
        BCi = ROL(Eko, 25);
        Emu ^= Du;
        BCo = ROL(Emu, 8);
        Esa ^= Da;
        BCu = ROL(Esa, 18);
        Aka = BCa ^ ((~BCe) & BCi);
        Ake = BCe ^ ((~BCi) & BCo);
        Aki = BCi ^ ((~BCo) & BCu);
        Ako = BCo ^ ((~BCu) & BCa);
        Aku = BCu ^ ((~BCa) & BCe);

        Ebu ^= Du;
        BCa = ROL(Ebu, 27);
        Ega ^= Da;
        BCe = ROL(Ega, 36);
        Eke ^= De;
        BCi = ROL(Eke, 10);
        Emi ^= Di;
        BCo = ROL(Emi, 15);
        Eso ^= Do;
        BCu = ROL(Eso, 56);
        Ama = BCa ^ ((~BCe) & BCi);
        Ame = BCe ^ ((~BCi) & BCo);
        Ami = BCi ^ ((~BCo) & BCu);
        Amo = BCo ^ ((~BCu) & BCa);
        Amu = BCu ^ ((~BCa) & BCe);

        Ebi ^= Di;
        BCa = ROL(Ebi, 62);
        Ego ^= Do;
        BCe = ROL(Ego, 55);
        Eku ^= Du;
        BCi = ROL(Eku, 39);
        Ema ^= Da;
        BCo = ROL(Ema, 41);
        Ese ^= De;
        BCu = ROL(Ese, 2);
        Asa = BCa ^ ((~BCe) & BCi);
        Ase = BCe ^ ((~BCi) & BCo);
        Asi = BCi ^ ((~BCo) & BCu);
        Aso = BCo ^ ((~BCu) & BCa);
        Asu = BCu ^ ((~BCa) & BCe);
    }

    // copyToState(state, A)
    state[0] = Aba;
    state[1] = Abe;
    state[2] = Abi;
    state[3] = Abo;
    state[4] = Abu;
    state[5] = Aga;
    state[6] = Age;
    state[7] = Agi;
    state[8] = Ago;
    state[9] = Agu;
    state[10] = Aka;
    state[11] = Ake;
    state[12] = Aki;
    state[13] = Ako;
    state[14] = Aku;
    state[15] = Ama;
    state[16] = Ame;
    state[17] = Ami;
    state[18] = Amo;
    state[19] = Amu;
    state[20] = Asa;
    state[21] = Ase;
    state[22] = Asi;
    state[23] = Aso;
    state[24] = Asu;
}

static void keccak_init(uint64_t s[25]) {
    unsigned int i;
    for (i = 0; i < 25; i++)
        s[i] = 0;
}

static unsigned int keccak_absorb(uint64_t s[25], unsigned int pos,
    unsigned int r, const uint8_t* in,
    size_t inlen) {
    unsigned int i;

    while (pos + inlen >= r) {
        for (i = pos; i < r; i++)
            s[i / 8] ^= (uint64_t)*in++ << 8 * (i % 8);
        inlen -= r - pos;
        KeccakF1600_StatePermute(s);
        pos = 0;
    }

    for (i = pos; i < pos + inlen; i++)
        s[i / 8] ^= (uint64_t)*in++ << 8 * (i % 8);

    return i;
}

static void keccak_finalize(uint64_t s[25], unsigned int pos, unsigned int r,
    uint8_t p) {
    s[pos / 8] ^= (uint64_t)p << 8 * (pos % 8);
    s[r / 8 - 1] ^= 1ULL << 63;
}

static unsigned int keccak_squeeze(uint8_t* out, size_t outlen, uint64_t s[25],
    unsigned int pos, unsigned int r) {

    unsigned int i;

    while (outlen) {
        if (pos == r) {
            KeccakF1600_StatePermute(s);
            pos = 0;
        }
        for (i = pos; i < r && i < pos + outlen; i++)
            *out++ = s[i / 8] >> 8 * (i % 8);
        outlen -= i - pos;
        pos = i;
    }

    return pos;
}

static void keccak_absorb_once(uint64_t s[25], unsigned int r,
    const uint8_t* in, size_t inlen, uint8_t p) {
    unsigned int i;

    for (i = 0; i < 25; i++)
        s[i] = 0;

    while (inlen >= r) {
        for (i = 0; i < r / 8; i++)
            s[i] ^= load64(in + 8 * i);
        in += r;
        inlen -= r;
        KeccakF1600_StatePermute(s);
    }

    for (i = 0; i < inlen; i++)
        s[i / 8] ^= (uint64_t)in[i] << 8 * (i % 8);

    s[i / 8] ^= (uint64_t)p << 8 * (i % 8);
    s[(r - 1) / 8] ^= 1ULL << 63;
}

static void keccak_squeezeblocks(uint8_t* out, size_t nblocks, uint64_t s[25],
    unsigned int r) {
    unsigned int i;

    while (nblocks) {
        KeccakF1600_StatePermute(s);
        for (i = 0; i < r / 8; i++)
            store64(out + 8 * i, s[i]);
        out += r;
        nblocks -= 1;
    }
}

void shake128_init(keccak_state* state) {
    keccak_init(state->s);
    state->pos = 0;
}

void shake128_absorb(keccak_state* state, const uint8_t* in, size_t inlen) {
    state->pos = keccak_absorb(state->s, state->pos, SHAKE128_RATE, in, inlen);
}

void shake128_finalize(keccak_state* state) {
    keccak_finalize(state->s, state->pos, SHAKE128_RATE, 0x1F);
    state->pos = SHAKE128_RATE;
}

void shake128_squeeze(uint8_t* out, size_t outlen, keccak_state* state) {
    state->pos =
        keccak_squeeze(out, outlen, state->s, state->pos, SHAKE128_RATE);
}

void shake128_absorb_once(keccak_state* state, const uint8_t* in,
    size_t inlen) {
    keccak_absorb_once(state->s, SHAKE128_RATE, in, inlen, 0x1F);
    state->pos = SHAKE128_RATE;
}

void shake128_squeezeblocks(uint8_t* out, size_t nblocks, keccak_state* state) {
    keccak_squeezeblocks(out, nblocks, state->s, SHAKE128_RATE);
}

void shake256_init(keccak_state* state) {
    keccak_init(state->s);
    state->pos = 0;
}

void shake256_absorb(keccak_state* state, const uint8_t* in, size_t inlen) {
    state->pos = keccak_absorb(state->s, state->pos, SHAKE256_RATE, in, inlen);
}

void shake256_finalize(keccak_state* state) {
    keccak_finalize(state->s, state->pos, SHAKE256_RATE, 0x1F);
    state->pos = SHAKE256_RATE;
}

void shake256_squeeze(uint8_t* out, size_t outlen, keccak_state* state) {
    state->pos =
        keccak_squeeze(out, outlen, state->s, state->pos, SHAKE256_RATE);
}

void shake256_absorb_once(keccak_state* state, const uint8_t* in,
    size_t inlen) {
    keccak_absorb_once(state->s, SHAKE256_RATE, in, inlen, 0x1F);
    state->pos = SHAKE256_RATE;
}

void shake256_squeezeblocks(uint8_t* out, size_t nblocks, keccak_state* state) {
    keccak_squeezeblocks(out, nblocks, state->s, SHAKE256_RATE);
}

void shake128(uint8_t* out, size_t outlen, const uint8_t* in, size_t inlen) {
    size_t nblocks;
    keccak_state state;

    shake128_absorb_once(&state, in, inlen);
    nblocks = outlen / SHAKE128_RATE;
    shake128_squeezeblocks(out, nblocks, &state);
    outlen -= nblocks * SHAKE128_RATE;
    out += nblocks * SHAKE128_RATE;
    shake128_squeeze(out, outlen, &state);
}

void shake256(uint8_t* out, size_t outlen, const uint8_t* in, size_t inlen) {
    size_t nblocks;
    keccak_state state;

    shake256_absorb_once(&state, in, inlen);
    nblocks = outlen / SHAKE256_RATE;
    shake256_squeezeblocks(out, nblocks, &state);
    outlen -= nblocks * SHAKE256_RATE;
    out += nblocks * SHAKE256_RATE;
    shake256_squeeze(out, outlen, &state);
}

void sha3_256(uint8_t h[32], const uint8_t* in, size_t inlen) {
    unsigned int i;
    uint64_t s[25];

    keccak_absorb_once(s, SHA3_256_RATE, in, inlen, 0x06);
    KeccakF1600_StatePermute(s);
    for (i = 0; i < 4; i++)
        store64(h + 8 * i, s[i]);
}

void sha3_512(uint8_t h[64], const uint8_t* in, size_t inlen) {
    unsigned int i;
    uint64_t s[25];

    keccak_absorb_once(s, SHA3_512_RATE, in, inlen, 0x06);
    KeccakF1600_StatePermute(s);
    for (i = 0; i < 8; i++)
        store64(h + 8 * i, s[i]);
}




int verify(const uint8_t* a, const uint8_t* b, size_t len) {
    size_t i;
    uint8_t r = 0;

    for (i = 0; i < len; i++)
        r |= a[i] ^ b[i];       // c1 = c1', c2 = c2' 일 경우 r = 0, 다르면 r = 1


    return ((uint64_t)(-(int64_t)(r))) >> 63;    // 검증 실패시 1, 성공시 0을 return
}

void cmov(uint8_t* r, const uint8_t* x, size_t len, uint8_t b) {
    size_t i;

    b = -b;
    for (i = 0; i < len; i++)
        r[i] ^= b & (r[i] ^ x[i]);
}


void poly_add(poly* r, const poly* a, const poly* b) {
    unsigned int i;
    for (i = 0; i < LWE_N; i++)
        r->coeffs[i] = a->coeffs[i] + b->coeffs[i];
}

void poly_sub(poly* r, const poly* a, const poly* b) {
    unsigned int i;
    for (i = 0; i < LWE_N; i++)
        r->coeffs[i] = a->coeffs[i] - b->coeffs[i];
}

#if MUL_MOD == 0

static void karatsuba_simple(const uint16_t* a_1, const uint16_t* b_1,
    uint16_t* result_final) {
    uint16_t d01[KARATSUBA_N / 2 - 1];
    uint16_t d0123[KARATSUBA_N / 2 - 1];
    uint16_t d23[KARATSUBA_N / 2 - 1];
    uint16_t result_d01[KARATSUBA_N - 1];

    int32_t i, j;

    memset(result_d01, 0, (KARATSUBA_N - 1) * sizeof(uint16_t));
    memset(d01, 0, (KARATSUBA_N / 2 - 1) * sizeof(uint16_t));
    memset(d0123, 0, (KARATSUBA_N / 2 - 1) * sizeof(uint16_t));
    memset(d23, 0, (KARATSUBA_N / 2 - 1) * sizeof(uint16_t));
    memset(result_final, 0, (2 * KARATSUBA_N - 1) * sizeof(uint16_t));

    uint16_t acc1, acc2, acc3, acc4, acc5, acc6, acc7, acc8, acc9, acc10;

    for (i = 0; i < KARATSUBA_N / 4; i++) {
        acc1 = a_1[i];                       // a0 = A[ 0 ~ 15]
        acc2 = a_1[i + KARATSUBA_N / 4];     // a1 = A[16 ~ 31]
        acc3 = a_1[i + 2 * KARATSUBA_N / 4]; // a2 = A[32 ~ 47]
        acc4 = a_1[i + 3 * KARATSUBA_N / 4]; // a3 = A[48 ~ 63]

        for (j = 0; j < KARATSUBA_N / 4; j++) {

            acc5 = b_1[j];                   // b0 = B[ 0 ~ 15]
            acc6 = b_1[j + KARATSUBA_N / 4]; // b1 = B[16 ~ 31]

            result_final[i + j + 0 * KARATSUBA_N / 4] =
                result_final[i + j + 0 * KARATSUBA_N / 4] +
                OVERFLOWING_MUL(acc1, acc5);                    // a0 * b0                                  -> result[ 0 ~ 30]  = (a0 * b0)
            result_final[i + j + 2 * KARATSUBA_N / 4] =
                result_final[i + j + 2 * KARATSUBA_N / 4] +
                OVERFLOWING_MUL(acc2, acc6);                    // a1 * b1                                  -> result[32 ~ 62]  = (a1 * b1)

            acc7 = acc5 + acc6; // b01                          // acc7 = b0 + b1
            acc8 = acc1 + acc2; // a01                          // acc8 = a0 + a1
            d01[i + j] = d01[i + j] + (uint16_t)(acc7 * (uint64_t)acc8);    // d01 = (a0 + a1)(b0 + b1)
            //--------------------------------------------------------

            acc7 = b_1[j + 2 * KARATSUBA_N / 4]; // b2          // b2 = B[32 ~ 47]
            acc8 = b_1[j + 3 * KARATSUBA_N / 4]; // b3          // b3 = B[48 ~ 63]
            result_final[i + j + 4 * KARATSUBA_N / 4] =
                result_final[i + j + 4 * KARATSUBA_N / 4] +
                OVERFLOWING_MUL(acc7, acc3);                    // a2 * b2                                  -> result[64 ~ 94]  = (a2 * b2)

            result_final[i + j + 6 * KARATSUBA_N / 4] =
                result_final[i + j + 6 * KARATSUBA_N / 4] +
                OVERFLOWING_MUL(acc8, acc4);                    // a3 * b3                                  -> result[96 ~ 127] = (a3 * b3)

            acc9 = acc3 + acc4;                                 // acc9  = a2 + a3
            acc10 = acc7 + acc8;                                // acc10 = b2 + b3
            d23[i + j] = d23[i + j] + OVERFLOWING_MUL(acc9, acc10);     // d23 = (a2 + a3)(b2 + b3)
            //--------------------------------------------------------

            acc5 = acc5 + acc7; // b02                          // acc5 = b0 + b2
            acc7 = acc1 + acc3; // a02                          // acc7 = a0 + a2
            result_d01[i + j + 0 * KARATSUBA_N / 4] =
                result_d01[i + j + 0 * KARATSUBA_N / 4] +
                OVERFLOWING_MUL(acc5, acc7);                    // (b0 + b2)(a0 + a2)   [ 0 ~ 30]

            acc6 = acc6 + acc8; // b13                          // acc6 = b1 + b3
            acc8 = acc2 + acc4;                                 // acc8 = a1 + a3
            result_d01[i + j + 2 * KARATSUBA_N / 4] =
                result_d01[i + j + 2 * KARATSUBA_N / 4] +
                OVERFLOWING_MUL(acc6, acc8);                    // (b1 + b3)(a1 + a3)   [32 ~ 62]

            acc5 = acc5 + acc6;                                 // acc5 = b0 + b1 + b2 + b3
            acc7 = acc7 + acc8;                                 // acc7 = a0 + a1 + a2 + a3
            d0123[i + j] = d0123[i + j] + OVERFLOWING_MUL(acc5, acc7);  // d0123 = (a0 + a1 + a2 + a3)(b0 + b1 + b2 + b3)
        }
    }

    // 2nd last stage

    for (i = 0; i < KARATSUBA_N / 2 - 1; i++) {
        d0123[i] = d0123[i] - result_d01[i + 0 * KARATSUBA_N / 4] -     // d0123 = (a0 + a1 + a2 + a3)(b0 + b1 + b2 + b3) - (b0 + b2)(a0 + a2) - (b1 + b3)(a1 + a3)
            result_d01[i + 2 * KARATSUBA_N / 4];
        d01[i] = d01[i] - result_final[i + 0 * KARATSUBA_N / 4] -       // d01[ 0 ~ 30]   = (a0 + a1)(b0 + b1) - a0 * b0 - a1 * b1 
            result_final[i + 2 * KARATSUBA_N / 4];
        d23[i] = d23[i] - result_final[i + 4 * KARATSUBA_N / 4] -       // d23[ 0 ~ 30]   = (a2 + a3)(b2 + b3) - a2 * b2 - a3 * b3
            result_final[i + 6 * KARATSUBA_N / 4];
    }

    for (i = 0; i < KARATSUBA_N / 2 - 1; i++) {
        result_d01[i + 1 * KARATSUBA_N / 4] =                           // result_d01[16 ~ 30] = (a0 + a2)(b0 + b2)[16 ~ 30] + {(a0 + a1 + a2 + a3)(b0 + b1 + b2 + b3) - (b0 + b2)(a0 + a2) - (b1 + b3)(a1 + a3)}[0 ~ 14]
            result_d01[i + 1 * KARATSUBA_N / 4] + d0123[i];             // result_d01[31 ~ 46] = {(a0 + a1 + a2 + a3)(b0 + b1 + b2 + b3) - (b0 + b2)(a0 + a2) - (b1 + b3)(a1 + a3)}[15 ~ 30]

        result_final[i + 1 * KARATSUBA_N / 4] =                         // result[16 ~ 30]     = a0 * b0[16 ~ 30] + {(a0 + a1)(b0 + b1) - a0 * b0 - a1 * b1}[ 0 ~ 14]
            result_final[i + 1 * KARATSUBA_N / 4] + d01[i];             // result[31]          = {(a0 + a1)(b0 + b1) - a0 * b0 - a1 * b1}[15]
        // result[32 ~ 46]     = a1 * b1[ 0 ~ 14] + {(a0 + a1)(b0 + b1) - a0 * b0 - a1 * b1}[16 ~ 30]

        result_final[i + 5 * KARATSUBA_N / 4] =                         // result[80 ~ 94]     = a2 * b2[16 ~ 30] + {(a2 + a3)(b2 + b3) - a2 * b2 - a3 * b3}[ 0 ~ 14]
            result_final[i + 5 * KARATSUBA_N / 4] + d23[i];             // result[95]          = {(a2 + a3)(b2 + b3) - a2 * b2 - a3 * b3}[15]
        // result[96 ~ 110]    = a3 * b3[ 0 ~ 14] + {(a2 + a3)(b2 + b3) - a2 * b2 - a3 * b3}[16 ~ 30]
    }

    // Last stage
    for (i = 0; i < KARATSUBA_N - 1; i++) {
        result_d01[i] =
            result_d01[i] - result_final[i] - result_final[i + KARATSUBA_N];    // result_d01[ 0 ~ 62] = (A1 + A0)(B1 + B0) - A1B1 - A0B0
    }

    for (i = 0; i < KARATSUBA_N - 1; i++) {
        result_final[i + 1 * KARATSUBA_N / 2] =
            result_final[i + 1 * KARATSUBA_N / 2] + result_d01[i];              // result[32 ~ 62] += result_d01[ 0 ~ 30]
    }                                                                           // result[63]      += result_d01[31]
                                                                                // result[64 ~ 94] += result_d01[32 ~ 62]
}

static void toom_cook_4way(const uint16_t* a1, const uint16_t* b1,
    uint16_t* result) {
    uint16_t inv3 = 43691, inv9 = 36409, inv15 = 61167;

    uint16_t aw1[N_SB], aw2[N_SB], aw3[N_SB], aw4[N_SB], aw5[N_SB], aw6[N_SB],
        aw7[N_SB];  // 2^6, 즉, 256차 -> 64차 7개로 쪼갠다는 의미임
    uint16_t bw1[N_SB], bw2[N_SB], bw3[N_SB], bw4[N_SB], bw5[N_SB], bw6[N_SB],
        bw7[N_SB];  // 곱할 수인 b부분 역시 64차 7개로 쪼개줌
    uint16_t w1[N_SB_RES] = { 0 }, w2[N_SB_RES] = { 0 }, w3[N_SB_RES] = { 0 },
        w4[N_SB_RES] = { 0 }, w5[N_SB_RES] = { 0 }, w6[N_SB_RES] = { 0 },
        w7[N_SB_RES] = { 0 };
    uint16_t r0, r1, r2, r3, r4, r5, r6, r7;
    uint16_t* A0, * A1, * A2, * A3, * B0, * B1, * B2, * B3;

    /*
        a1의 경우

    */
    A0 = (uint16_t*)a1;            // A0 = a1[0   ~  63]
    A1 = (uint16_t*)&a1[N_SB];     // A1 = a1[64  ~ 127]
    A2 = (uint16_t*)&a1[2 * N_SB]; // A2 = a1[128 ~ 191]
    A3 = (uint16_t*)&a1[3 * N_SB]; // A3 = a1[192 ~ 255]
    B0 = (uint16_t*)b1;
    B1 = (uint16_t*)&b1[N_SB];
    B2 = (uint16_t*)&b1[2 * N_SB];
    B3 = (uint16_t*)&b1[3 * N_SB];

    uint16_t* C;
    C = result;

    int i, j;

    // EVALUATION   평가 지점은 infty, 2, 1, -1, 1/2, -1/2, 0
    for (j = 0; j < N_SB; ++j) {
        r0 = A0[j];                 // r0 = a1[i]
        r1 = A1[j];                 // r1 = a1[i + 64]
        r2 = A2[j];                 // r2 = a1[i + 128]
        r3 = A3[j];                 // r3 = a1[i + 192]
        r4 = r0 + r2;               // r4 = a1[i] + a1[i + 128]
        r5 = r1 + r3;               // r5 = a1[i + 64] + a1[i + 192]
        r6 = r4 + r5;               // r6 = a1[i] + a1[i + 64] + a1[i + 128] + a1[i + 192]
        r7 = r4 - r5;               // r7 = a1[i] + a1[i + 128] - a1[i + 64] + a1[i + 192]
        aw3[j] = r6;                // aw3 = a1[i] + a1[i + 64] + a1[i + 128] + a1[i + 192] -> 평가 지점 A( 1)
        aw4[j] = r7;                // aw4 = a1[i] - a1[i + 64] + a1[i + 128] + a1[i + 192] -> 평가 지점 A(-1)

        r4 = ((r0 << 2) + r2) << 1; // r4 = 8 * a1[i]                  + 2 * a1[i + 128] 
        r5 = (r1 << 2) + r3;        // r5 =             4 * a1[i + 64]                   + a1[i + 192] 
        r6 = r4 + r5;               // r6 = 8 * a1[i] + 4 * a1[i + 64] + 2 * a1[i + 128] + a1[i + 192]
        r7 = r4 - r5;               // r7 = 8 * a1[i] - 4 * a1[i + 64] + 2 * a1[i + 128] - a1[i + 192]
        aw5[j] = r6;                // aw5 = 8 * a1[i] + 4 * a1[i + 64] + 2 * a1[i + 128] + a1[i + 192] -> 평가 지점 8 * A( 1/2)
        aw6[j] = r7;                // aw6 = 8 * a1[i] - 4 * a1[i + 64] + 2 * a1[i + 128] - a1[i + 192] -> 평가 지점 8 * A(-1/2)
        r4 = (r3 << 3) + (r2 << 2) + (r1 << 1) + r0;    // r4 = a1[i] + 2 * a1[i + 64] + 4 * a1[i + 128] + 8 * a1[i + 192]
        aw2[j] = r4;                // aw2 = a1[i] + 2 * a1[i + 64] + 4 * a1[i + 128] + 8 * a1[i + 192] -> 평가 지점 A(2)
        aw7[j] = r0;                // aw7 = a1[i]       -> 평가 지점 A(0)
        aw1[j] = r3;                // aw1 = a1[i + 192] -> 평가 지점 A(infty)
    }
    for (j = 0; j < N_SB; ++j) {
        r0 = B0[j];
        r1 = B1[j];
        r2 = B2[j];
        r3 = B3[j];
        r4 = r0 + r2;
        r5 = r1 + r3;
        r6 = r4 + r5;
        r7 = r4 - r5;
        bw3[j] = r6;
        bw4[j] = r7;
        r4 = ((r0 << 2) + r2) << 1;
        r5 = (r1 << 2) + r3;
        r6 = r4 + r5;
        r7 = r4 - r5;
        bw5[j] = r6;
        bw6[j] = r7;
        r4 = (r3 << 3) + (r2 << 2) + (r1 << 1) + r0;
        bw2[j] = r4;
        bw7[j] = r0;
        bw1[j] = r3;
    } // B 역시 마찬가지로 평가 지점은 infty, 2, 1, -1, 1/2, -1/2, 0

    // MULTIPLICATION
    karatsuba_simple(aw1, bw1, w1); // A(infty) * B(infty)  = w1 (64차 끼리의 곱셈을 진행하는데, 2-level Karatsuba이기 때문에, 내부에서 4개로 변경하여 연산을 진행한다.)
    karatsuba_simple(aw2, bw2, w2); // A(2)     * B(2)      = w2
    karatsuba_simple(aw3, bw3, w3); // A(1)     * B(1)      = w3
    karatsuba_simple(aw4, bw4, w4); // A(-1)    * B(-1)     = w4
    karatsuba_simple(aw5, bw5, w5); // A(1/2)   * B(1/2)    = w5
    karatsuba_simple(aw6, bw6, w6); // A(-1/2)  * B(-1/2)   = w6
    karatsuba_simple(aw7, bw7, w7); // A(0)     * B(0)      = w7

    // 각 값에 대해 2-level karatsuba 연산을 이용해서 평가 값을 계산

    // INTERPOLATION
/* 보간 행렬.

c0 =    r6 =       0	    0	   0	    0	    0	    0	   1           r0 (infty)
c1 =    r5 =    -1/2	 1/90	-1/3	  1/9	 1/36	-1/60	-1/2           r1 (2)
c2 =    r4 =     1/4	    0	-1/6	 -1/6	 1/24	 1/24	  -5           r2 (1)
c3 =    r3 =     5/2	-1/18	 3/2	-7/18	-1/18	    0	 5/2           r3 (-1)
c4 =    r2 =    -5/4	    0	 2/3	  2/3	-1/24	-1/24	   4           r4 (1/2)
c5 =    r1 =      -2	 2/45	-2/3	 -2/9	 1/36	 1/60	  -2           r5 (-1/2)
c6 =    r0 =       1	    0	   0	    0	    0	    0	   0           r6 (0)

*/
    for (i = 0; i < N_SB_RES; ++i) {
        r0 = w1[i];
        r1 = w2[i];
        r2 = w3[i];
        r3 = w4[i];
        r4 = w5[i];
        r5 = w6[i];
        r6 = w7[i];

        r1 = r1 + r4;                                               // r1 = r(1) + r(4)
        r5 = r5 - r4;                                               // r5 = r(5) - r(4)
        r3 = ((r3 - r2) >> 1);                                      // r3 = (r(3) - r(2)) / 2
        r4 = r4 - r0;                                               // r4 = r(4) - r(0)
        r4 = r4 - (r6 << 6);                                        // r4 = r(4) - r(0) - 64 * r(6)
        r4 = (r4 << 1) + r5;                                        // r4 = 2 * (r(4) - r(0) - 64 * r(6)) + r(5) - r(4)
        r2 = r2 + r3;                                               // r2 = r(2) + (r(3) - r(2)) / 2
        r1 = r1 - (r2 << 6) - r2;                                   // r1 = r(1) + r(4) - 64 * (r(2) + (r(3) - r(2)) / 2) - r(2) + (r(3) - r(2)) / 2
        r2 = r2 - r6;                                               // r2 = r(2) + (r(3) - r(2)) / 2 - r(6)
        r2 = r2 - r0;                                               // r2 = r(2) + (r(3) - r(2)) / 2 - r(6) - r(0)
        r1 = r1 + 45 * r2;                                          // r1 = r(1) + r(4) - 64 * (r(2) + (r(3) - r(2)) / 2) - r(2) + (r(3) - r(2)) / 2 + 45 * (r(2) + (r(3) - r(2)) / 2 - r(6) - r(0))
        r4 = (uint16_t)(((r4 - (r2 << 3)) * (uint32_t)inv3) >> 3);  // r4 = {2 * (r(4) - r(0) - 64 * r(6)) + r(5) - r(4) - 8 * (r(2) + (r(3) - r(2)) / 2 - r(6) - r(0))} * 1/24
        r5 = r5 + r1;                                               // r5 = r(5) + r(4) + r(1) + r(4) - 64 * (r(2) + (r(3) - r(2)) / 2) - r(2) + (r(3) - r(2)) / 2 + 45 * (r(2) + (r(3) - r(2)) / 2 - r(6) - r(0))
        r1 = (uint16_t)(((r1 + (r3 << 4)) * (uint32_t)inv9) >> 1);  // r1 = {r(1) + r(4) - 64 * (r(2) + (r(3) - r(2)) / 2) - r(2) + (r(3) - r(2)) / 2 + 45 * (r(2) + (r(3) - r(2)) / 2 - r(6) - r(0)) + 8 * ((r(3) - r(2)))} * 1/18
        r3 = -(r3 + r1);                                            // r3 = - {(r(3) - r(2)) / 2} - {r(1) + r(4) - 64 * (r(2) + (r(3) - r(2)) / 2) - r(2) + (r(3) - r(2)) / 2 + 45 * (r(2) + (r(3) - r(2)) / 2 - r(6) - r(0)) + 8 * ((r(3) - r(2)))} * 1/18
        r5 = (uint16_t)(((30 * r1 - r5) * (uint32_t)inv15) >> 2);   // r5 = {30 * ({r(1) + r(4) - 64 * (r(2) + (r(3) - r(2)) / 2) - r(2) + (r(3) - r(2)) / 2 + 45 * (r(2) + (r(3) - r(2)) / 2 - r(6) - r(0)) + 8 * ((r(3) - r(2)))} * 1/18) - r(5) + r(4) + r(1) + r(4) - 64 * (r(2) + (r(3) - r(2)) / 2) - r(2) + (r(3) - r(2)) / 2 + 45 * (r(2) + (r(3) - r(2)) / 2 - r(6) - r(0))} * 1/60
        r2 = r2 - r4;                                               // r2 = r(2) + (r(3) - r(2)) / 2 - r(6) - r(0) - {{2 * (r(4) - r(0) - 64 * r(6)) + r(5) + r(4) - 8 * (r(2) + (r(3) - r(2)) / 2 - r(6) - r(0))} * 1/24}
        r1 = r1 - r5;                                               // r1 = {r(1) + r(4) - 64 * (r(2) + (r(3) - r(2)) / 2) - r(2) + (r(3) - r(2)) / 2 + 45 * (r(2) + (r(3) - r(2)) / 2 - r(6) - r(0)) + 8 * ((r(3) - r(2)))} * 1/18 - {{30 * ({r(1) + r(4) - 64 * (r(2) + (r(3) - r(2)) / 2) - r(2) + (r(3) - r(2)) / 2 + 45 * (r(2) + (r(3) - r(2)) / 2 - r(6) - r(0)) + 8 * ((r(3) - r(2)))} * 1/18) - r(5) + r(4) + r(1) + r(4) - 64 * (r(2) + (r(3) - r(2)) / 2) - r(2) + (r(3) - r(2)) / 2 + 45 * (r(2) + (r(3) - r(2)) / 2 - r(6) - r(0))} * 1/60}

        C[i] += r6;         // C[  0 ~ 126]
        C[i + 64] += r5;    // C[ 64 ~ 190]
        C[i + 128] += r4;   // C[128 ~ 254]
        C[i + 192] += r3;   // C[192 ~ 318]
        C[i + 256] += r2;   // C[256 ~ 382]
        C[i + 320] += r1;   // C[320 ~ 446]
        C[i + 384] += r0;   // C[384 ~ 510]
    }
}

/* res += a*b */
void poly_mul_acc(const int16_t a[LWE_N], const int16_t b[LWE_N],
    int16_t res[LWE_N]) {
    uint16_t c[2 * LWE_N] = { 0 };
    int i;

    toom_cook_4way((uint16_t*)a, (uint16_t*)b, c);

    /* reduction */
    for (i = LWE_N; i < 2 * LWE_N; i++) {           // SMAUG-T을 Quotient 하는 irred_poly 는 x^256 + 1 이기 때문에
        res[i - LWE_N] += (c[i - LWE_N] - c[i]);    // c[0~510]에서 c[256 ~ 510] -> -c[0 ~ 254] 이므로
    }                                               // res[0~255] = c[0 ~ 255] - c[256 ~ 510] 으로 reduction 을 진행
}

void vec_vec_mult(poly* r, const polyvec* a, const polyvec* b) {
    unsigned int i;
    for (i = 0; i < MODULE_RANK; i++)
        poly_mul_acc(a->vec[i].coeffs, b->vec[i].coeffs, r->coeffs);
}

void vec_vec_mult_add(poly* r, const polyvec* a, const polyvec* b,
    const uint8_t mod) {
    unsigned int i, j;
    polyvec al;
    poly res;

    for (i = 0; i < MODULE_RANK; ++i)
        for (j = 0; j < LWE_N; ++j)
            al.vec[i].coeffs[j] = a->vec[i].coeffs[j] >> mod;   // 원래 bit모양으로 변경해주고

    memset(&res, 0, sizeof(poly));
    vec_vec_mult(&res, &al, b);         // res = b * r  
    // dec의 경우 c1 * s
    for (j = 0; j < LWE_N; ++j)
        res.coeffs[j] <<= mod;          // res = b * r << mod 다시 최대 bit를 모두 쓰도록 해줌(ex) uint16_t 이기 때문에 16bit를 쓰도록)

    poly_add(r, r, &res);               // r = q/t * mu + b * r
}                                       // dec의 경우 c2 + c1 * s

void matrix_vec_mult_add(polyvec* r, const polyvec a[MODULE_RANK],
    const polyvec* b) {
    unsigned int i, j, k;
    polyvec at;

    for (i = 0; i < MODULE_RANK; ++i) {
        for (j = 0; j < MODULE_RANK; ++j)
            for (k = 0; k < LWE_N; ++k)
                at.vec[j].coeffs[k] = a[j].vec[i].coeffs[k] >> _16_LOG_Q;   // 상위 10bit만 남겨주고

        vec_vec_mult(&r->vec[i], &at, b);       // A*r
        for (j = 0; j < LWE_N; ++j)
            r->vec[i].coeffs[j] <<= _16_LOG_Q;  // 상위 10bit를 유효하게 만들어주고
    }
}

void matrix_vec_mult_sub(polyvec* r, const polyvec a[MODULE_RANK],
    const polyvec* b) {
    unsigned int i, j, k;
    polyvec al;
    poly res;

    for (i = 0; i < MODULE_RANK; ++i) {
        for (j = 0; j < MODULE_RANK; ++j)
            for (k = 0; k < LWE_N; ++k)
                al.vec[j].coeffs[k] = a[i].vec[j].coeffs[k] >> _16_LOG_Q;   // A 행렬 mod q(2^10)

        memset(&res, 0, sizeof(poly));
        vec_vec_mult(&res, &al, b);             // A * s
        for (j = 0; j < LWE_N; ++j)
            res.coeffs[j] <<= _16_LOG_Q;        // e값을 side channel을 막기 위해 <<6 을 진행했기 때문에 A*s 역시 마찬가지로 진행

        poly_sub(&r->vec[i], &r->vec[i], &res); // e - A*s 즉 b = -As + e 의 값을 얻어줌
    }
}

#elif MUL_MOD == 1

static const int32_t zetas[LWE_N] = {
    0, 25847, -2608894, -518909, 237124, -777960, -876248, 466468,
    1826347, 2353451, -359251, -2091905, 3119733, -2884855, 3111497, 2680103,
    2725464, 1024112, -1079900, 3585928, -549488, -1119584, 2619752, -2108549,
    -2118186, -3859737, -1399561, -3277672, 1757237, -19422, 4010497, 280005,
    2706023, 95776, 3077325, 3530437, -1661693, -3592148, -2537516, 3915439,
    -3861115, -3043716, 3574422, -2867647, 3539968, -300467, 2348700, -539299,
    -1699267, -1643818, 3505694, -3821735, 3507263, -2140649, -1600420, 3699596,
    811944, 531354, 954230, 3881043, 3900724, -2556880, 2071892, -2797779,
    -3930395, -1528703, -3677745, -3041255, -1452451, 3475950, 2176455, -1585221,
    -1257611, 1939314, -4083598, -1000202, -3190144, -3157330, -3632928, 126922,
    3412210, -983419, 2147896, 2715295, -2967645, -3693493, -411027, -2477047,
    -671102, -1228525, -22981, -1308169, -381987, 1349076, 1852771, -1430430,
    -3343383, 264944, 508951, 3097992, 44288, -1100098, 904516, 3958618,
    -3724342, -8578, 1653064, -3249728, 2389356, -210977, 759969, -1316856,
    189548, -3553272, 3159746, -1851402, -2409325, -177440, 1315589, 1341330,
    1285669, -1584928, -812732, -1439742, -3019102, -3881060, -3628969, 3839961,
    2091667, 3407706, 2316500, 3817976, -3342478, 2244091, -2446433, -3562462,
    266997, 2434439, -1235728, 3513181, -3520352, -3759364, -1197226, -3193378,
    900702, 1859098, 909542, 819034, 495491, -1613174, -43260, -522500,
    -655327, -3122442, 2031748, 3207046, -3556995, -525098, -768622, -3595838,
    342297, 286988, -2437823, 4108315, 3437287, -3342277, 1735879, 203044,
    2842341, 2691481, -2590150, 1265009, 4055324, 1247620, 2486353, 1595974,
    -3767016, 1250494, 2635921, -3548272, -2994039, 1869119, 1903435, -1050970,
    -1333058, 1237275, -3318210, -1430225, -451100, 1312455, 3306115, -1962642,
    -1279661, 1917081, -2546312, -1374803, 1500165, 777191, 2235880, 3406031,
    -542412, -2831860, -1671176, -1846953, -2584293, -3724270, 594136, -3776993,
    -2013608, 2432395, 2454455, -164721, 1957272, 3369112, 185531, -1207385,
    -3183426, 162844, 1616392, 3014001, 810149, 1652634, -3694233, -1799107,
    -3038916, 3523897, 3866901, 269760, 2213111, -975884, 1717735, 472078,
    -426683, 1723600, -1803090, 1910376, -1667432, -1104333, -260646, -3833893,
    -2939036, -2235985, -420899, -2286327, 183443, -976891, 1612842, -3545687,
    -554416, 3919660, -48306, -1362209, 3937738, 1400424, -846154, 1976782 };

int32_t montgomery_reduce(int64_t a) {
    int32_t t;
    t = (int32_t)((uint64_t)a * (uint64_t)NTT_QINV);
    t = (a - (int64_t)t * NTT_Q) >> 32;
    return t;
}

//* CT-butterfly in Forward-NTT
void ntt(int32_t a[LWE_N]) {
    unsigned int len, start, j, k;
    int32_t zeta, t;

    k = 0;
    for (len = 128; len > 0; len >>= 1) {
        for (start = 0; start < LWE_N; start = j + len) {
            zeta = zetas[++k];
            for (j = start; j < start + len; ++j) {
                t = montgomery_reduce((int64_t)zeta * a[j + len]);
                a[j + len] = a[j] - t;
                a[j] = a[j] + t;
            }
        }
    }
}

void inv_ntt(int32_t a[LWE_N]) {
    unsigned int start, len, j, k;
    int32_t t, zeta;
    const int32_t f = 41978;	// mont^2/256

    k = 256;
    for (len = 1; len < LWE_N; len <<= 1) {
        for (start = 0; start < LWE_N; start = j + len) {
            zeta = -zetas[--k];
            for (j = start; j < start + len; ++j) {
                t = a[j];
                a[j] = t + a[j + len];
                a[j + len] = t - a[j + len];
                a[j + len] = montgomery_reduce((int64_t)zeta * a[j + len]);
            }
        }
    }

    for (j = 0; j < LWE_N; ++j) {
        a[j] = montgomery_reduce((int64_t)f * a[j]);
    }
}


// void ntt_mul(int32_t* r, int32_t* a, int32_t* b) {
//     for (int i = 0; i < LWE_N; i++) {
//         r[i] = montgomery_reduce((int64_t)a[i] * b[i]);
//     }
// }

void ntt_mul_acc(int32_t* r, int32_t* a, int32_t* b) {
    for (int i = 0; i < LWE_N; i++) {
        r[i] += montgomery_reduce((int64_t)a[i] * b[i]);
    }
}

void vec_vec_mult_add(poly* r, const polyvec* a, const polyvec* b,
    const uint8_t mod) {
    unsigned int i, j;
    poly res;

    int32_t al_tmp[LWE_N] = { 0x00 };
    int32_t b_tmp[LWE_N] = { 0x00 };
    int32_t res_tmp[LWE_N] = { 0x00 };

    for (i = 0; i < MODULE_RANK; ++i) {
        for (j = 0; j < LWE_N; ++j) {
            al_tmp[j] = (int32_t)(int16_t)(a->vec[i].coeffs[j] >> mod);
            b_tmp[j] = (int32_t)(int16_t)(b->vec[i].coeffs[j]);
        }

        ntt(al_tmp);
        ntt(b_tmp);

        // if (i == 0) {
        //     ntt_mul(res_tmp, al_tmp, b_tmp);
        // }
        // else {
        //     ntt_mul_acc(res_tmp, al_tmp, b_tmp);
        // }
        ntt_mul_acc(res_tmp, al_tmp, b_tmp);
    }

    inv_ntt(res_tmp);
    for (j = 0; j < LWE_N; ++j) {
        //! MLWR 특성으로 저장할 때 left shift, 사용할 때 right shift
        //! 따라서 원래 q로 되돌리지 않아도 된다!
        //! res.coeffs[j] = (uint16_t)(res_tmp[j] & ((1 << LOG_Q) - 1));
        res.coeffs[j] = (uint16_t)(res_tmp[j]);
        res.coeffs[j] <<= mod;
    }

    poly_add(r, r, &res);
}

void matrix_vec_mult_add(polyvec* r, const polyvec a[MODULE_RANK],
    const polyvec* b) {
    unsigned int i, j, k;
    // polyvec at;

    int32_t at_tmp[LWE_N] = { 0x00 };
    int32_t b_tmp[MODULE_RANK][LWE_N] = { 0x00 };


    //* ntt(b)
    for (i = 0; i < MODULE_RANK; i++) {
        for (j = 0; j < LWE_N; j++) {
            b_tmp[i][j] = b->vec[i].coeffs[j];
        }
        ntt(b_tmp[i]);
    }

    for (i = 0; i < MODULE_RANK; ++i) {
        int32_t res_tmp[LWE_N] = { 0x00 };
        for (j = 0; j < MODULE_RANK; ++j) {
            for (k = 0; k < LWE_N; ++k) {
                at_tmp[k] = (int32_t)(int16_t)(a[j].vec[i].coeffs[k] >> _16_LOG_Q);
            }

            ntt(at_tmp);

            // if (j == 0) {
            //     ntt_mul(res_tmp, at_tmp, b_tmp[j]);
            // }
            // else {
            //     ntt_mul_acc(res_tmp, at_tmp, b_tmp[j]);
            // }
            ntt_mul_acc(res_tmp, at_tmp, b_tmp[j]);
        }

        inv_ntt(res_tmp);
        for (j = 0; j < LWE_N; ++j) {
            // r->vec[i].coeffs[j] = (uint16_t)(res_tmp[j] & ((1 << LOG_Q) - 1));
            r->vec[i].coeffs[j] = (uint16_t)res_tmp[j];
            r->vec[i].coeffs[j] <<= _16_LOG_Q;
        }
    }
}

void matrix_vec_mult_sub(polyvec* r, const polyvec a[MODULE_RANK],
    const polyvec* b) {
    unsigned int i, j, k;
    // polyvec al;
    poly res;

    int32_t al_tmp[LWE_N] = { 0x00 };
    int32_t b_tmp[MODULE_RANK][LWE_N] = { 0x00 };


    //* ntt(b)
    for (i = 0; i < MODULE_RANK; i++) {
        for (j = 0; j < LWE_N; j++) {
            b_tmp[i][j] = b->vec[i].coeffs[j];
        }
        ntt(b_tmp[i]);
    }

    for (i = 0; i < MODULE_RANK; ++i) {
        int32_t res_tmp[LWE_N] = { 0x00 };
        for (j = 0; j < MODULE_RANK; ++j) {
            for (k = 0; k < LWE_N; ++k) {
                al_tmp[k] = (int32_t)(int16_t)(a[i].vec[j].coeffs[k] >> _16_LOG_Q);
            }

            ntt(al_tmp);

            // if (j == 0) {
            //     ntt_mul(res_tmp, al_tmp, b_tmp[j]);
            // }
            // else {
            //     ntt_mul_acc(res_tmp, al_tmp, b_tmp[j]);
            // }

            ntt_mul_acc(res_tmp, al_tmp, b_tmp[j]);

        }
        inv_ntt(res_tmp);
        for (j = 0; j < LWE_N; ++j) {
            // res.coeffs[j] = (uint16_t)(res_tmp[j] & ((1 << LOG_Q) - 1));
            res.coeffs[j] = (uint16_t)res_tmp[j];
            res.coeffs[j] <<= _16_LOG_Q;
        }

        poly_sub(&r->vec[i], &r->vec[i], &res);
    }
}


#endif


void Rq_to_bytes(uint8_t bytes[PKPOLY_BYTES], const poly* data) {
    int16_t tmp[LWE_N] = { 0 };
    int b_idx = 0, d_idx = 0;
    unsigned int i, j;

#if LOG_Q == 10
    for (i = 0; i < LWE_N; ++i) {
        bytes[i] = data->coeffs[i] >> 8;        // bytes[i]에 b값의 상위 8bit를 저장  ->
        tmp[i] = data->coeffs[i] & 0x00c0;      // tmp[i]에 b값의 중위 2bit를 저장    -> 실제로 필요한 값인 10bit만을 저장한다는 의미임
    }
    int16_t buf[DATA_OFFSET * 2] = { 0 };
    for (i = 0; i < 2; ++i) {
        for (j = 0; j < DATA_OFFSET; ++j) {
            buf[b_idx + j] = tmp[d_idx + j] << 8;  // buf[0~15 + 8*b_idx] = tmp[0  ~ 15 + 128*b_idx] 1100 0000 0000 0000 
            buf[b_idx + j] |= tmp[d_idx + DATA_OFFSET + j] << 6;  // buf[0~15 + 8*b_idx] = tmp[16 ~ 31 + 128*b_idx] 0011 0000 0000 0000
            buf[b_idx + j] |= tmp[d_idx + DATA_OFFSET * 2 + j] << 4;  // buf[0~15 + 8*b_idx] = tmp[32 ~ 47 + 128*b_idx] 0000 1100 0000 0000
            buf[b_idx + j] |= tmp[d_idx + DATA_OFFSET * 3 + j] << 2;  // buf[0~15 + 8*b_idx] = tmp[48 ~ 63 + 128*b_idx] 0000 0011 0000 0000
            buf[b_idx + j] |= tmp[d_idx + DATA_OFFSET * 4 + j];       // buf[0~15 + 8*b_idx] = tmp[64 ~ 79 + 128*b_idx] 0000 0000 1100 0000 
            buf[b_idx + j] |= tmp[d_idx + DATA_OFFSET * 5 + j] >> 2;  // buf[0~15 + 8*b_idx] = tmp[80 ~ 95 + 128*b_idx] 0000 0000 0011 0000
            buf[b_idx + j] |= tmp[d_idx + DATA_OFFSET * 6 + j] >> 4;  // buf[0~15 + 8*b_idx] = tmp[96 ~111 + 128*b_idx] 0000 0000 0000 1100
            buf[b_idx + j] |= tmp[d_idx + DATA_OFFSET * 7 + j] >> 6;  // buf[0~15 + 8*b_idx] = tmp[112~127 + 128*b_idx] 0000 0000 0000 0011
        }                                                             // 위와 같이 값을 저장
        b_idx += DATA_OFFSET;
        d_idx += DATA_OFFSET * 8;
    }
    store16_littleendian(bytes + LWE_N, buf, DATA_OFFSET * 2);        // 저장한 값을 byte 형식으로 bytes[256~319] 에 저장
#endif
#if LOG_Q == 11
    for (i = 0; i < LWE_N; ++i) {
        bytes[i] = data->coeffs[i] >> 8;
        tmp[i] = data->coeffs[i] & 0x00e0;
    }
    int shift = 5;
    int16_t buf[DATA_OFFSET * 3] = { 0 };
    for (i = 0; i < 3; ++i) {
        for (j = 0; j < DATA_OFFSET; ++j) {
            buf[b_idx + j] = (tmp[j] >> shift) & 0x01;
            buf[b_idx + j] |= tmp[d_idx + DATA_OFFSET + j] << 8;
            buf[b_idx + j] |= tmp[d_idx + DATA_OFFSET * 2 + j] << 5;
            buf[b_idx + j] |= tmp[d_idx + DATA_OFFSET * 3 + j] << 2;
            buf[b_idx + j] |= tmp[d_idx + DATA_OFFSET * 4 + j] >> 1;
            buf[b_idx + j] |= tmp[d_idx + DATA_OFFSET * 5 + j] >> 4;
        }
        b_idx += DATA_OFFSET;
        d_idx += DATA_OFFSET * 5;
        shift++;
    }
    store16_littleendian(bytes + LWE_N, buf, DATA_OFFSET * 3);
#endif
}

void bytes_to_Rq(poly* data, const uint8_t bytes[PKPOLY_BYTES]) {
    int16_t tmp[LWE_N] = { 0 };
    int b_idx = 0, d_idx = 0;
    unsigned int i, j;

#if LOG_Q == 10
    for (i = 0; i < LWE_N; ++i)
        data->coeffs[i] = (int16_t)bytes[i] << 8;               // data->coeffs[i]의 상위 8bit를 shake128의 결과값으로 집어 넣어 줌
    // enc 과정에서는 b 행렬을 저장

    int16_t buf[DATA_OFFSET * 2] = { 0 };
    load16_littleendian(buf, DATA_OFFSET * 2, bytes + LWE_N);   // buf 배열에 들어가지 않은 나머지 bytes 값을 저장
    // 320 - 256 = 64 즉, buf[i] = bytes[2i+1] | bytes[2i] 으로 저장해줌

    for (i = 0; i < 2; ++i) {
        for (j = 0; j < DATA_OFFSET; ++j) {
            tmp[d_idx + j] = buf[b_idx + j] >> 8; // temp[0  ~ 15 + 128*d_i] = buf[0~15 + 16*b_i] >> 8; temp에 buf의 상위 8bit를 저장
            tmp[d_idx + DATA_OFFSET + j] = buf[b_idx + j] >> 6; // temp[16 ~ 31 + 128*d_i] = buf[0~15 + 16*b_i] >> 6; temp에 buf의 상위 10bit를 저장
            tmp[d_idx + DATA_OFFSET * 2 + j] = buf[b_idx + j] >> 4; // temp[32 ~ 47 + 128*d_i] = buf[0~15 + 16*b_i] >> 4; temp에 buf의 상위 12bit를 저장
            tmp[d_idx + DATA_OFFSET * 3 + j] = buf[b_idx + j] >> 2; // temp[48 ~ 63 + 128*d_i] = buf[0~15 + 16*b_i] >> 2; temp에 buf의 상위 14bit를 저장
            tmp[d_idx + DATA_OFFSET * 4 + j] = buf[b_idx + j];      // temp[64 ~ 79 + 128*d_i] = buf[0~15 + 16*b_i];      temp에 buf를 저장
            tmp[d_idx + DATA_OFFSET * 5 + j] = buf[b_idx + j] << 2; // temp[80 ~ 95 + 128*d_i] = buf[0~15 + 16*b_i] << 2; temp에 buf의 하위 14bit | 00 으로 저장
            tmp[d_idx + DATA_OFFSET * 6 + j] = buf[b_idx + j] << 4; // temp[96 ~111 + 128*d_i] = buf[0~15 + 16*b_i] << 4; temp에 buf의 하위 12bit | 0000 으로 저장
            tmp[d_idx + DATA_OFFSET * 7 + j] = buf[b_idx + j] << 6; // temp[112~127 + 128*d_i] = buf[0~15 + 16*b_i] << 6; temp에 buf의 하위 10bit | 000000으로 저장
        }
        b_idx += DATA_OFFSET;
        d_idx += DATA_OFFSET * 8;
    }
    for (i = 0; i < LWE_N; ++i)
        data->coeffs[i] |= tmp[i] & 0x00c0; // coeff[i] = coeff[i] | (temp[i] & 0b 0000 0000 1100 0000)
    // 즉, coeff[i] | temp[i]의 7, 6번 bit를 coeff의 7, 6번 bit로 사용하겠다는 의미
    // -> 앞에서 data->coeffs[i]의 값은 상위 8bit만을 뽑아서 사용했음,
    // 여기에서, >> 6을 통해 각 계수의 값을 상위 10bit만을 사용할 것이기 때문에 마지막 2bit를 temp를 통해 채우겠다는 의미임
#endif
#if LOG_Q == 11
    for (i = 0; i < LWE_N; ++i)
        data->coeffs[i] = (int16_t)bytes[i] << 8;

    int16_t buf[DATA_OFFSET * 3] = { 0 };
    load16_littleendian(buf, DATA_OFFSET * 3, bytes + LWE_N);

    int shift = 5;
    for (i = 0; i < 3; ++i) {
        for (j = 0; j < DATA_OFFSET; ++j) {
            tmp[j] |= (buf[b_idx + j] & 0x01) << shift;
            tmp[d_idx + DATA_OFFSET + j] = buf[b_idx + j] >> 8;
            tmp[d_idx + DATA_OFFSET * 2 + j] = buf[b_idx + j] >> 5;
            tmp[d_idx + DATA_OFFSET * 3 + j] = buf[b_idx + j] >> 2;
            tmp[d_idx + DATA_OFFSET * 4 + j] = buf[b_idx + j] << 1;
            tmp[d_idx + DATA_OFFSET * 5 + j] = buf[b_idx + j] << 4;
        }
        b_idx += DATA_OFFSET;
        d_idx += DATA_OFFSET * 5;
        shift++;
    }
    for (i = 0; i < LWE_N; ++i)
        data->coeffs[i] |= tmp[i] & 0x00e0;
#endif
}

void Rq_vec_to_bytes(uint8_t bytes[PKPOLYVEC_BYTES], const polyvec* data) {
    unsigned int i;
    for (i = 0; i < MODULE_RANK; ++i)
        Rq_to_bytes(bytes + i * PKPOLY_BYTES, &(data->vec[i])); // b vector는 10bit 표현이기 때문에 10 * 256 / 8 = 320 byte로 하나의 b module을 저장할 수 있음
}

void bytes_to_Rq_vec(polyvec* data, const uint8_t bytes[PKPOLYVEC_BYTES]) {
    unsigned int i;
    for (i = 0; i < MODULE_RANK; ++i)
        bytes_to_Rq(&(data->vec[i]), bytes + i * PKPOLY_BYTES);
}

void Rq_mat_to_bytes(uint8_t bytes[PKPOLYMAT_BYTES],
    const polyvec data[MODULE_RANK]) {
    unsigned int i;
    for (i = 0; i < MODULE_RANK; ++i)
        Rq_vec_to_bytes(bytes + i * PKPOLYVEC_BYTES, &(data[i]));
}

void bytes_to_Rq_mat(polyvec data[MODULE_RANK],
    const uint8_t bytes[PKPOLYMAT_BYTES]) {
    unsigned int i;
    for (i = 0; i < MODULE_RANK; ++i)
        bytes_to_Rq_vec(&(data[i]), bytes + i * PKPOLYVEC_BYTES);
}

void Rp_to_bytes(uint8_t bytes[CTPOLY1_BYTES], const poly* data) {
#if LOG_P == 8
    unsigned int i;
    memset(bytes, 0, sizeof(uint8_t) * CTPOLY1_BYTES);
    for (i = 0; i < LWE_N; ++i)
        memcpy(&(bytes[i]), &(data->coeffs[i]), sizeof(uint8_t));   // 8bit로 압축했다면, 그대로 저장하면 됨
#endif
#if LOG_P == 9
    int16_t tmp[LWE_N] = { 0 };

    unsigned int i;
    for (i = 0; i < LWE_N; ++i) {
        bytes[i] = data->coeffs[i] & 0xff;
        tmp[i] = data->coeffs[i] & 0x00100;
    }

    int16_t buf[DATA_OFFSET] = { 0 };
    for (i = 0; i < DATA_OFFSET; ++i) {
        buf[i] = tmp[i] << 7;
        buf[i] |= tmp[DATA_OFFSET + i] << 6;
        buf[i] |= tmp[DATA_OFFSET * 2 + i] << 5;
        buf[i] |= tmp[DATA_OFFSET * 3 + i] << 4;
        buf[i] |= tmp[DATA_OFFSET * 4 + i] << 3;
        buf[i] |= tmp[DATA_OFFSET * 5 + i] << 2;
        buf[i] |= tmp[DATA_OFFSET * 6 + i] << 1;
        buf[i] |= tmp[DATA_OFFSET * 7 + i];
        buf[i] |= tmp[DATA_OFFSET * 8 + i] >> 1;
        buf[i] |= tmp[DATA_OFFSET * 9 + i] >> 2;
        buf[i] |= tmp[DATA_OFFSET * 10 + i] >> 3;
        buf[i] |= tmp[DATA_OFFSET * 11 + i] >> 4;
        buf[i] |= tmp[DATA_OFFSET * 12 + i] >> 5;
        buf[i] |= tmp[DATA_OFFSET * 13 + i] >> 6;
        buf[i] |= tmp[DATA_OFFSET * 14 + i] >> 7;
        buf[i] |= tmp[DATA_OFFSET * 15 + i] >> 8;
    }
    store16_littleendian(bytes + LWE_N, buf, DATA_OFFSET);
#endif
}

void Rp2_to_bytes(uint8_t bytes[CTPOLY2_BYTES], const poly* data) {
    memset(bytes, 0, sizeof(uint8_t) * CTPOLY2_BYTES);
#if LOG_P2 == 5
    unsigned int i;
    int b_idx = 0;
    int d_idx = 0;
    for (i = 0; i < LWE_N / 8; ++i) {
        b_idx = 5 * i;
        d_idx = 8 * i;

        bytes[b_idx] = (data->coeffs[d_idx] & 0x1f) |
            ((data->coeffs[d_idx + 1] & 0x7) << 5);
        bytes[b_idx + 1] = (data->coeffs[d_idx + 1] & 0x18) >> 3 |
            ((data->coeffs[d_idx + 2] & 0x1f) << 2) |
            ((data->coeffs[d_idx + 3] & 0x01) << 7);
        bytes[b_idx + 2] = ((data->coeffs[d_idx + 3] & 0x1e) >> 1) |
            ((data->coeffs[d_idx + 4] & 0xf) << 4);
        bytes[b_idx + 3] = ((data->coeffs[d_idx + 4] & 0x10) >> 4) |
            ((data->coeffs[d_idx + 5] & 0x1f) << 1) |
            ((data->coeffs[d_idx + 6] & 0x3) << 6);
        bytes[b_idx + 4] = ((data->coeffs[d_idx + 6] & 0x1c) >> 2) |
            ((data->coeffs[d_idx + 7] & 0x1f) << 3);
    }       // 저장한 값이 5bit이기 때문에 5bit 8개 -> 1byte 5개 로 encoding 진행
#endif
#if LOG_P2 == 4
    unsigned int i;
    for (i = 0; i < LWE_N / 2; ++i) {
        bytes[i] = data->coeffs[2 * i] & 0x000f;
        bytes[i] |= (data->coeffs[2 * i + 1] << 4) & 0x00f0;
    }
#endif
#if LOG_P2 == 7
    int d_idx = CTPOLY2_BYTES;
    unsigned int i, j;

    int shift[7] = { 1, 2, 3, 4, 5, 6, 7 };
    int16_t buf[DATA_OFFSET * 7] = { 0 };
    for (i = 0; i < 2; ++i) {
        for (j = 0; j < DATA_OFFSET; ++j) {
            buf[j] |= (data->coeffs[d_idx + j] & 0x40) << shift[0];
            buf[DATA_OFFSET + j] |= (data->coeffs[d_idx + j] & 0x20)
                << shift[1];
            buf[DATA_OFFSET * 2 + j] |= (data->coeffs[d_idx + j] & 0x10)
                << shift[2];
            buf[DATA_OFFSET * 3 + j] |= (data->coeffs[d_idx + j] & 0x08)
                << shift[3];
            buf[DATA_OFFSET * 4 + j] |= (data->coeffs[d_idx + j] & 0x04)
                << shift[4];
            buf[DATA_OFFSET * 5 + j] |= (data->coeffs[d_idx + j] & 0x02)
                << shift[5];
            buf[DATA_OFFSET * 6 + j] |= (data->coeffs[d_idx + j] & 0x01)
                << shift[6];
        }
        d_idx += DATA_OFFSET;
        for (j = 0; j < 7; ++j)
            shift[j] += 8;
    }

    uint8_t tmp[CTPOLY2_BYTES] = { 0 };
    store16_littleendian(tmp, buf, DATA_OFFSET * 7);
    for (i = 0; i < CTPOLY2_BYTES; ++i)
        bytes[i] = tmp[i] | (data->coeffs[i] & 0x7f);
#endif
}

void bytes_to_Rp(poly* data, const uint8_t bytes[CTPOLY1_BYTES]) {
#if LOG_P == 8
    unsigned int i;
    memset(data, 0, sizeof(poly));
    for (i = 0; i < LWE_N; ++i)
        memcpy(&(data->coeffs[i]), &(bytes[i]), sizeof(uint8_t));   // 8bit로 줄였기 때문에 그대로 사용하면 됨
#endif
#if LOG_P == 9
    int16_t tmp[LWE_N] = { 0 };
    unsigned int i;
    for (i = 0; i < LWE_N; ++i)
        data->coeffs[i] = (int16_t)bytes[i];

    int16_t buf[DATA_OFFSET] = { 0 };
    load16_littleendian(buf, DATA_OFFSET, bytes + LWE_N);

    for (i = 0; i < DATA_OFFSET; ++i) {
        tmp[i] = buf[i] >> 7;
        tmp[DATA_OFFSET + i] = buf[i] >> 6;
        tmp[DATA_OFFSET * 2 + i] = buf[i] >> 5;
        tmp[DATA_OFFSET * 3 + i] = buf[i] >> 4;
        tmp[DATA_OFFSET * 4 + i] = buf[i] >> 3;
        tmp[DATA_OFFSET * 5 + i] = buf[i] >> 2;
        tmp[DATA_OFFSET * 6 + i] = buf[i] >> 1;
        tmp[DATA_OFFSET * 7 + i] = buf[i];
        tmp[DATA_OFFSET * 8 + i] = buf[i] << 1;
        tmp[DATA_OFFSET * 9 + i] = buf[i] << 2;
        tmp[DATA_OFFSET * 10 + i] = buf[i] << 3;
        tmp[DATA_OFFSET * 11 + i] = buf[i] << 4;
        tmp[DATA_OFFSET * 12 + i] = buf[i] << 5;
        tmp[DATA_OFFSET * 13 + i] = buf[i] << 6;
        tmp[DATA_OFFSET * 14 + i] = buf[i] << 7;
        tmp[DATA_OFFSET * 15 + i] = buf[i] << 8;
    }
    for (i = 0; i < LWE_N; ++i)
        data->coeffs[i] |= tmp[i] & 0x00100;
#endif
}

void bytes_to_Rp2(poly* data, const uint8_t bytes[CTPOLY2_BYTES]) {
    memset(data, 0, sizeof(int16_t) * LWE_N);
#if LOG_P2 == 5
    unsigned int i;
    int b_idx = 0;
    int d_idx = 0;
    for (i = 0; i < LWE_N / 8; ++i) {
        b_idx = 5 * i;
        d_idx = 8 * i;

        data->coeffs[d_idx] = bytes[b_idx] & 0x1f;
        data->coeffs[d_idx + 1] =
            ((bytes[b_idx] & 0xe0) >> 5) | ((bytes[b_idx + 1] & 0x3) << 3);
        data->coeffs[d_idx + 2] = ((bytes[b_idx + 1] & 0x7c) >> 2);
        data->coeffs[d_idx + 3] =
            ((bytes[b_idx + 1] & 0x80) >> 7) | ((bytes[b_idx + 2] & 0xf) << 1);
        data->coeffs[d_idx + 4] =
            ((bytes[b_idx + 2] & 0xf0) >> 4) | ((bytes[b_idx + 3] & 0x1) << 4);
        data->coeffs[d_idx + 5] = ((bytes[b_idx + 3] & 0x3e) >> 1);
        data->coeffs[d_idx + 6] =
            ((bytes[b_idx + 3] & 0xc0) >> 6) | ((bytes[b_idx + 4] & 0x7) << 2);
        data->coeffs[d_idx + 7] = (bytes[b_idx + 4] & 0xf8) >> 3;
        // 1byte 5개 -> 5bit 8개로 decoding 진행
    }
#endif
#if LOG_P2 == 4
    unsigned int i;
    for (i = 0; i < LWE_N / 2; ++i) {
        data->coeffs[2 * i] = bytes[i] & 0x0f;
        data->coeffs[2 * i + 1] = (bytes[i] & 0xf0) >> 4;
    }
#endif
#if LOG_P2 == 7
    int d_idx = CTPOLY2_BYTES;
    unsigned int i, j;
    for (i = 0; i < CTPOLY2_BYTES; ++i)
        data->coeffs[i] = (int16_t)bytes[i] & 0x7f;

    uint8_t tmp[CTPOLY2_BYTES] = { 0 };
    int16_t buf[DATA_OFFSET * 7] = { 0 };
    for (i = 0; i < CTPOLY2_BYTES; ++i)
        tmp[i] = bytes[i] & 0x80;
    load16_littleendian(buf, DATA_OFFSET * 7, tmp);

    int shift[7] = { 1, 2, 3, 4, 5, 6, 7 };
    for (i = 0; i < 2; ++i) {
        for (j = 0; j < DATA_OFFSET; ++j) {
            data->coeffs[d_idx + j] |= (buf[j] >> shift[0]) & 0x40;
            data->coeffs[d_idx + j] |=
                (buf[DATA_OFFSET + j] >> shift[1]) & 0x20;
            data->coeffs[d_idx + j] |=
                (buf[DATA_OFFSET * 2 + j] >> shift[2]) & 0x10;
            data->coeffs[d_idx + j] |=
                (buf[DATA_OFFSET * 3 + j] >> shift[3]) & 0x08;
            data->coeffs[d_idx + j] |=
                (buf[DATA_OFFSET * 4 + j] >> shift[4]) & 0x04;
            data->coeffs[d_idx + j] |=
                (buf[DATA_OFFSET * 5 + j] >> shift[5]) & 0x02;
            data->coeffs[d_idx + j] |=
                (buf[DATA_OFFSET * 6 + j] >> shift[6]) & 0x01;
        }
        d_idx += DATA_OFFSET;
        for (j = 0; j < 7; ++j)
            shift[j] += 8;
    }
#endif
}

void Rp_vec_to_bytes(uint8_t bytes[CTPOLYVEC_BYTES], const polyvec* data) {
    unsigned int i;
    for (i = 0; i < MODULE_RANK; ++i)
        Rp_to_bytes(bytes + i * CTPOLY1_BYTES, &(data->vec[i]));
}

void bytes_to_Rp_vec(polyvec* data, const uint8_t bytes[CTPOLYVEC_BYTES]) {
    unsigned int i;
    for (i = 0; i < MODULE_RANK; ++i)
        bytes_to_Rp(&(data->vec[i]), bytes + i * CTPOLY1_BYTES);
}

void Sx_to_bytes(uint8_t* bytes, const poly* data) {
    unsigned int i;
    int d_idx = 0;
    for (i = 0; i < LWE_N / 4; ++i) {
        d_idx = i * 4;
        bytes[i] = (data->coeffs[d_idx] & 0x03) |       // data->coeff[4*idx + 0] & 0011
            ((data->coeffs[d_idx + 1] & 0x03) << 2) |   // data->coeff[4*idx + 1] & 0011
            ((data->coeffs[d_idx + 2] & 0x03) << 4) |   // data->coeff[4*idx + 2] & 0011
            ((data->coeffs[d_idx + 3] & 0x03) << 6);    // data->coeff[4*idx + 3] & 0011 을
    }                                                   // byte[i] = coef[3] | coef[2] | coef[1] | coef[0] 으로 저장
}

void bytes_to_Sx(poly* data, const uint8_t* bytes) {
    unsigned int i;
    int d_idx = 0;
    for (i = 0; i < LWE_N / 4; ++i) {
        d_idx = i * 4;
        uint8_t t[4] = { 0 };                               // sk의 경우 1 -> 01, -1 -> 11, 0 -> 00로 저장되어 있음

        t[0] = (bytes[i] & 0x03);                           // byte의 0000 0011 을 t[0]에 저장
        t[1] = ((bytes[i] >> 2) & 0x03);                    // byte의 0000 1100 을 t[1]에 저장
        t[2] = ((bytes[i] >> 4) & 0x03);                    // byte의 0011 0000 을 t[2]에 저장
        t[3] = ((bytes[i] >> 6) & 0x03);                    // byte의 1100 0000 을 t[3]에 저장
        data->coeffs[d_idx] = t[0] | (-(t[0] >> 1));
        data->coeffs[d_idx + 1] = t[1] | (-(t[1] >> 1));
        data->coeffs[d_idx + 2] = t[2] | (-(t[2] >> 1));
        data->coeffs[d_idx + 3] = t[3] | (-(t[3] >> 1));    // data에 byte(string sk)값을 01 -> 1,  11 -> -1,  0 -> 0 로 저장
    }
}


#if SMAUG_MODE == 1

static void sp_cbd1(poly* r, const uint8_t buf[CBDSEED_BYTES]) {
    unsigned int i, j;
    uint32_t t, d, s;
    int16_t a;

    for (i = 0; i < LWE_N / 8; i++) {
        t = load24_littleendian(buf + 3 * i);   // 0x00249249 -> 0010 0100 1001 0010 0100 1001
        d = t & 0x00249249;                     // t의 001 001 001 001 001 001 001 001 bit를 d에 저장
        d &= (t >> 1) & 0x00249249;             // t의 010 010 010 010 010 010 010 010 bit를 중 위의 d와 똑같이 1일 경우 d에 저장 
        // 위의 두 과정을 통해 서로 다른 값을 x & y 한 것과 같음
        s = (t >> 2) & 0x00249249;              // t의 100 100 100 100 100 100 100 100 bit를 s에 저장

        for (j = 0; j < 8; j++) {
            a = (d >> (3 * j)) & 0x1;           // x & y의 한 비트씩을 a로 저장
            r->coeffs[8 * i + j] =
                a * (((((s >> (3 * j)) & 0x1) - 1) ^ -2) | 1);
        }       // s의 해당 bit가 1이라면,  a * ( ( 0 ^ -2) | 1 ) = a * ( -2 | 1 ) = a * -1
    }           // s의 해당 bit가 0이라면,  a * ( (-1 ^ -2) | 1 ) = a * (  1 | 1 ) = a *  1
}               // x, y에서 모두 1 -> d = 1 (1/4), x,y,s 가 1 -> -1, x,y가 1, s가 0 -> 1, 나머지 -> 0 이므로 1 (1/8), -1 (1/8), 0 (3/4) 인 spCBD이다.
#endif

#if SMAUG_MODE == 3

static void cbd(poly* r, const uint8_t buf[CBDSEED_BYTES]) {
    unsigned int i, j;
    uint32_t t;
    int16_t a, b;

    for (i = 0; i < LWE_N / 16; i++) {
        t = load32_littleendian(buf + 4 * i);

        for (j = 0; j < 16; j++) {
            a = (t >> (2 * j + 0)) & 0x01;  // t의 0101 0101 0101 0101 0101 0101 0101 0101 을 a에 저장
            b = (t >> (2 * j + 1)) & 0x01;  // t의 1010 1010 1010 1010 1010 1010 1010 1010 을 b에 저장
            r->coeffs[16 * i + j] = a - b;  // a - b를 진행하는 것으로 0 0 -> 0, 1 1 -> 0, 0 1 -> -1, 1 0 -> 1 으로 저장
        }                                   // 즉, 1(1/4), -1(1/4), 0(1/2) 인 spCBD이다.
    }
}
#endif

#if SMAUG_MODE == 5

static void sp_cbd2(poly* r, const uint8_t buf[CBDSEED_BYTES]) {
    unsigned int i, j;
    uint32_t t, s, d;
    int16_t a;

    for (i = 0; i < LWE_N / 8; i++) {
        t = load32_littleendian(buf + 4 * i);
        d = t & 0x11111111;
        d |= (t >> 1) & 0x11111111;
        d &= (t >> 2) & 0x11111111;
        s = (t >> 3) & 0x11111111;
        for (j = 0; j < 8; j++) {
            a = (d >> (4 * j)) & 0x1;
            r->coeffs[8 * i + j] = a * (((((s >> (4 * j)) & 0x1) - 1) ^ -2) | 1);
        }
    }
}
#endif

void shake256_absorb_twice_squeeze(uint8_t* out, size_t out_bytes,
    const uint8_t* in1, size_t in1_bytes,
    const uint8_t* in2, size_t in2_bytes) {
    keccak_state state;
    shake256_init(&state);
    shake256_absorb(&state, in1, in1_bytes);
    shake256_absorb(&state, in2, in2_bytes);
    shake256_finalize(&state);
    shake256_squeeze(out, out_bytes, &state);
}




int addGaussianError(poly* op, const uint8_t* seed) {
    unsigned int i = 0, j = 0, k = 0;
    uint64_t seed_temp[SEED_LEN] = { 0 };
    uint8_t buf[SEED_LEN * 8] = { 0 };
    uint64_t s[SLEN] = { 0 };
    uint64_t* x = NULL;

    shake256(buf, SEED_LEN * 8, seed, CRYPTO_BYTES + 1);
    load64_littleendian(seed_temp, SEED_LEN, buf);

    for (i = 0; i < LWE_N; i += 64) {
        x = seed_temp + j;
        s[0] = (x[0] & x[1] & x[2] & x[3] & x[4] & x[5] & x[7] & ~x[8]) |
            (x[0] & x[3] & x[4] & x[5] & x[6] & x[8]) |
            (x[1] & x[3] & x[4] & x[5] & x[6] & x[8]) |
            (x[2] & x[3] & x[4] & x[5] & x[6] & x[8]) |
            (~x[2] & ~x[3] & ~x[6] & x[8]) | (~x[1] & ~x[3] & ~x[6] & x[8]) |
            (x[6] & x[7] & ~x[8]) | (~x[5] & ~x[6] & x[8]) |
            (~x[4] & ~x[6] & x[8]) | (~x[7] & x[8]);
        s[1] = (x[1] & x[2] & x[4] & x[5] & x[7] & x[8]) |
            (x[3] & x[4] & x[5] & x[7] & x[8]) | (x[6] & x[7] & x[8]);
        for (k = 0; k < 64; ++k) {
            op->coeffs[i + k] =
                ((s[0] >> k) & 0x01) | (((s[1] >> k) & 0x01) << 1);
            uint16_t sign = (x[9] >> k) & 0x01;
            op->coeffs[i + k] = (((-sign) ^ op->coeffs[i + k]) + sign)
                << _16_LOG_Q;
        }
        j += RAND_BITS;
    }

    return 0;
}

void addGaussianErrorVec(polyvec* op, const uint8_t seed[CRYPTO_BYTES]) {
    unsigned int i;
    uint8_t extseed[CRYPTO_BYTES + 1] = { 0 };
    memcpy(extseed, seed, CRYPTO_BYTES);            // extseed[0~31] = seed[0~31]
    for (i = 0; i < MODULE_RANK; ++i) {
        extseed[CRYPTO_BYTES] = MODULE_RANK * i;    // extseed[32] = i * MODULE_RANK
        addGaussianError(&(op->vec[i]), extseed);   // Error값 e 생성, 이 때 side channel attack을 막기 위해 [-3,3]이 아닌 <<6 을 진행한 {-192, -128, -64, 0, 64, 128, 192}으로 e 생성
    }
}

// referenced
// Décio Luiz Gazzoni Filho and Tomás S. R. Silva and Julio López
// “Efficient isochronous fixed-weight sampling with applications to {NTRU},” in
// Cryptology {ePrint} Archive, Paper 2024/548. 2024,
// url: eprint.iacr.org/2024/548.
/*************************************************
 * Name:        rejsampling_mod
 *
 * Description: Sample array of random integers such that res[i] is in the range
 *              [0, LWE_N - i] for 0 <= i < LWE_N
 *
 * Arguments:   - uint8_t *res: pointer to ouptput polynomial r(x)
 *                (of length LWE), assumed to be already initialized
 *              - uint8_t *seed: pointer to input seed (of length
 *input_size)
 * 즉, res[i] 에 [0, 256 - i)를 비 편향적으로 sampling하는 코드임
 **************************************************/
static int rejsampling_mod(int16_t res[LWE_N], const uint16_t* rand) {
    unsigned int i, j = LWE_N;
    uint32_t m;
    uint16_t s, t, l;

    // rand 배열은 XOF를 통한 308개짜리 배열임

    for (i = 0; i < LWE_N; i++) {
        s = LWE_N - i;              // s = 256 - i
        t = 65536 % s;              // 2^L mod s

        m = (uint32_t)rand[i] * s;  // m = rand[i] * (256 - i)
        l = m;                      // l = m

        while (l < t) {             // rand[i] * (256 - i)  <  2^L mod 256 - i 이 거짓일 때 까지    - rand[i]가 언제나 범위 [ 0, 2^L / (256 - i) )에 존재하도록(비 편향적이게 하도록) 하는 조건
            if (j >= (HWTSEEDBYTES / 2))    // rand는 0 ~ 308 개짜리 배열이기 때문에 rand[308]은 존재 할 수 없음 -> 이 경우 reject
                return -1; // all randomness used
            m = (uint32_t)rand[j++] * s;    // m = rand[256++] * s
            l = m;                          // l = m
        }

        res[i] = m >> 16;           // rand[i] * (256 - i) or rand[256++] * (256 - i) >> 16
    }

    return 0;
}

int hwt(int16_t* res, const uint8_t* seed) {
    unsigned int i;
    int16_t si[LWE_N] = { 0 };
    uint16_t rand[HWTSEEDBYTES / 2] = { 0 };
    uint8_t sign[LWE_N / 4] = { 0 };
    uint8_t buf[HWTSEEDBYTES] = { 0 };

    keccak_state state;
    shake256_init(&state);
    shake256_absorb_once(&state, seed, CRYPTO_BYTES + 2);

    // only executed once with overwhelming probability:
    shake256_squeeze(buf, HWTSEEDBYTES, &state);        // sampling을 위한 값을 seed를 통해 생성

    load16_littleendian(rand, HWTSEEDBYTES / 2, buf);   // sampling 할 값을(uint8_t)  (int16_t) 형식으로 변경
    if (rejsampling_mod(si, rand))                      // rejection sampling을 진행
    {
        return -1;                                      // 이 때, rejection sampling을 하는 배열은 308개의 배열인데, 해당하는 배열로 원하는 값을 sampling하지 못하면 
    }                                                   // 사용하는 seed값을 변경하기 위해서 return -1

    shake256_squeeze(sign, LWE_N / 4, &state);          // hamming weight의 결과 값을 위한 sign 값을 생성
    // -> shake256_squeeze(sign, LWE_N / 8, &state); 로 변경해도 무방함

    int16_t t0;
    int16_t c0 = LWE_N - HS;        // 256 - 70 = 186
    for (i = 0; i < LWE_N; i++) {
        t0 = (si[i] - c0) >> 15;    // si[i] - c0 가 양수 -> 0   (si[i]의 값이 c0보다 크면)
        //               음수 -> -1  (si[i]의 값이 c0보다 작으면)

        c0 += t0;                   //               c0 + 0
        //               c0 - 1

        res[i] = 1 + t0;            // res = 1 + t0  양수 -> 1, 음수 -> 0
        // 즉, si[i]가 c0보다 클 때마다 res[i]에 1의 값을 넣어주는데,
        // 여기에서 c0보다 작으면 c0의 값을 -1 해주는 것으로 res[i]에 1을 넣을 범위를 늘려줌
        // 결국 계속해서 si[i]가 c0보다 작다면 맨 마지막 70개에 대해서는 무조건 c0보다 작아지기 때문에
        // 고정된 Hamming weight를 갖게 됨

        // Convert to ternary
        // index of sign: (i / 16 / 8) * 16 + (i % 16)
        // shift size   : (i / 16) % 8
        res[i] =
            (-res[i]) &
            ((((sign[(((i >> 4) >> 3) << 4) + (i & 0x0F)] >> ((i >> 4) & 0x07)) << 1) & 0x02) - 1); // = res_sign
    }           //  -res[i] & ( ( ( {sign[i / 16 / 8 * 16 + i % 16] >> (i / 16 % 8)}  << 1 ) & 0x02 ) - 1 )
                //                                                                    << 1 연산을 통해 해당 bit를 masking 하는 것과 같은 효과를 볼 수 있음
                //                  0x01이 아닌, << 1 & 0x02 를 한 이유는 하위 2bit를 남기고 싶기 때문에 즉, sign[index_of_sign]의 해당 bit 값이 1 -> (-res[i] & 1) -> 1,  0 -> (-res[i] & -1) -> -1로 남기기 위해서임

                //                  i : 0   ~ 127 -> index of sign : 0  ~ 15 를 반복, shift size : 0 ~ 7 까지 1씩 증가  -> ( (sign[0  ~ 15]의 모든 bit를 << 1 ) & 0x02) - 1 
                //                  i : 128 ~ 256 -> index of sign : 16 ~ 31 을 반복, shift size : 0 ~ 7 까지 1씩 증가  -> ( (sign[16 ~ 31]의 모든 bit를 << 1 ) & 0x02) - 1
                //                  
                // 결국 res[i] 에는 hamming weight HS짜리 +- 1인 작은 정보가 저장되게 됨
    return 0;

}

void poly_cbd(poly* r, const uint8_t buf[CBDSEED_BYTES]) {
#if SMAUG_MODE == 1
    sp_cbd1(r, buf);
#elif SMAUG_MODE == 3
    cbd(r, buf);
#elif SMAUG_MODE == 5
    sp_cbd2(r, buf);
#endif
}




void computeC1(polyvec* c1, const polyvec A[MODULE_RANK], const polyvec* r) {
    unsigned int i, j;

    // c1 = A * r
    matrix_vec_mult_add(c1, A, r);      // 여기에서 결과값은 상위 10bit에 저장되어 있음

    // Rounding q to p
    for (i = 0; i < MODULE_RANK; ++i) {
        for (j = 0; j < LWE_N; ++j) {
            c1->vec[i].coeffs[j] =                                          // 반올림을 보정값 RD_ADD를 더해주고
                ((c1->vec[i].coeffs[j] + RD_ADD) & RD_AND) >> _16_LOG_P;    // 남는 비트 수 만큼 남겨 준 후 결과값을 위해 >> 6 을 진행
        }
    }
}

void computeC2(poly* c2, const uint8_t delta[DELTA_BYTES], const polyvec* b,
    const polyvec* r) {
    unsigned int i, j;

    // c2 = q/2 * mu                         // 모든 SMAUG-T에 대해서 ssk seed인 mu의 크기를 줄이는 t는 2로 고정
    for (i = 0; i < DELTA_BYTES; ++i) {
        for (j = 0; j < sizeof(uint8_t) * 8; ++j) {
            c2->coeffs[8 * i + j] = (uint16_t)((delta[i] >> j) << _16_LOG_T);   // mu의 한 bit씩을 coeff의 첫 bit에 저장 (1000 0000 0000 0000)
        }                                                                       // 연산을 진행하는 과정을 제외하고는 SMAUG-T의 모든 bit는 상위 10bit를 이용하도록 되어있음
    }                                                                           // 원래, q/2 = 1024/2 = 512, mu << 9 -> 이는 상위 10bit를 이용한다는 전제 하에,
                                                                                // 16bit의 첫 번째 수가 되게 되어있음
                                                                                // 문서 : mu << 9
                                                                                // 코드 : mu << 15  (mu << 9 << 6 = mu << 15 이므로)
    // c2 = q/t * mu + (b * r)
    vec_vec_mult_add(c2, b, r, _16_LOG_Q);  // 16bit 중 상위 10bit 에 값을 저장하는 형식으로, c2 = q/t * mu + (b * r) 계산 완료

    // Rounding q to p'
    for (i = 0; i < LWE_N; ++i) {
        c2->coeffs[i] = ((c2->coeffs[i] + RD_ADD2) & RD_AND2) >> _16_LOG_P2;    // p'/t * mu + p'/q * (br)
    }   // 상위 LOG_P2 bit를 남길 생각이기 때문에 반올림 기준값인 RD_ADD2를 더해주고 상위 5bit, 16bit->5bit 로 c2에 결과 저장
}



void genAx(polyvec A[MODULE_RANK], const uint8_t seed[PKSEED_BYTES]) {
    unsigned int i, j;
    uint8_t buf[PKPOLY_BYTES] = { 0 }, tmpseed[PKSEED_BYTES + 2];
    memcpy(tmpseed, seed, PKSEED_BYTES);                            // tmpseed[0~31] = seed
    for (i = 0; i < MODULE_RANK; i++) {
        for (j = 0; j < MODULE_RANK; j++) {
            tmpseed[32] = i;
            tmpseed[33] = j;
            shake128(buf, PKPOLY_BYTES, tmpseed, PKSEED_BYTES + 2); // buf에 값을 생성해서
            bytes_to_Rq(&A[i].vec[j], buf);                         // A에 값을 저장, (상위 10bit -> 실제 A, 하위 6bit -> 00 0000 으로 저장되어 있음)
        }
    }
}

void genBx(polyvec* b, const polyvec A[MODULE_RANK], const polyvec* s,
    const uint8_t e_seed[CRYPTO_BYTES]) {
    // b = e
    addGaussianErrorVec(b, e_seed); // 생성한 seed[0~31]을 통해 dGaussian 함수로 에러값 생성

    // b = -a * s + e
    matrix_vec_mult_sub(b, A, s);
}

void genSx_vec(secret_key* sk, const uint8_t seed[CRYPTO_BYTES]) {
    unsigned int i, j;
    uint8_t extseed[CRYPTO_BYTES + 2] = { 0 };
    memcpy(extseed, seed, CRYPTO_BYTES);            // extseed에 seed를 저장                               // extseed[0~31] = seed[0~31]

    for (i = 0; i < MODULE_RANK; ++i) {
        extseed[CRYPTO_BYTES] = i * MODULE_RANK;    // seed의 바로 다음 byte를 module_rank * i 로 저장      // extseed[32] = module_rank * i
        j = 0;
        do {
            extseed[CRYPTO_BYTES + 1] = j;          // extseed의 마지막 byte를 j라고 두고,                  // extseed[33] = j
            j += 1;                                 // 해당 j값을 늘려가면서 조건에 맞는 extseed값을 찾아줌
        } while (hwt(sk->vec[i].coeffs, extseed));
    }
}

void genPubkey(public_key* pk, const secret_key* sk,
    const uint8_t err_seed[CRYPTO_BYTES]) {
    genAx(pk->A, pk->seed);                         // seed[32~63]을 통해 A 행렬 생성
    // 생성한 A 행렬은 10bit로 modulo 되어 있지 않고 16bit 표현임, 이후 genBx 함수를 통해서 modulo 연산이 진행됨

    memset(&(pk->b), 0, sizeof(uint16_t) * LWE_N);
    // Initialized at addGaussian, Unnecessary
    genBx(&(pk->b), pk->A, sk, err_seed);           // b = -As + e
}

void genRx_vec(polyvec* r, const uint8_t* input) {
    unsigned int i;
    uint8_t buf[CBDSEED_BYTES] = { 0 };

    for (i = 0; i < MODULE_RANK; ++i) {
        uint8_t extseed[DELTA_BYTES + 1];       // extseed[0~31] = seed[0~31]
        memcpy(extseed, input, DELTA_BYTES);
        extseed[DELTA_BYTES] = i;               // extseed[32] = 0 or 1

        shake256(buf, CBDSEED_BYTES, extseed, DELTA_BYTES + 1); // buf에 rejection sampling을 위한 XOF 의 결과를 저장
        poly_cbd(&r->vec[i], buf);              // rejection sampling(spCBD)을 통해 1 (1/8), -1 (1/8), 0 (3/4) 의 확률로 값을 갖도록 함
    }
}



void save_to_string(uint8_t* output, const ciphertext* ctxt) {
    Rp_vec_to_bytes(output, &(ctxt->c1));
    Rp2_to_bytes(output + CTPOLYVEC_BYTES, &(ctxt->c2));
}

void load_from_string(ciphertext* ctxt, const uint8_t* input) {
    bytes_to_Rp_vec(&(ctxt->c1), input);
    bytes_to_Rp2(&(ctxt->c2), input + CTPOLYVEC_BYTES);
}

void save_to_string_sk(uint8_t* output, const secret_key* sk) {
    for (size_t i = 0; i < MODULE_RANK; ++i)
        Sx_to_bytes(output + SKPOLY_BYTES * i, &sk->vec[i]);
}

void load_from_string_sk(secret_key* sk, const uint8_t* input) {
    for (size_t i = 0; i < MODULE_RANK; ++i)
        bytes_to_Sx(&sk->vec[i], input + SKPOLY_BYTES * i);
}

void save_to_string_pk(uint8_t* output, const public_key* pk) {
    memcpy(output, pk->seed, sizeof(uint8_t) * PKSEED_BYTES);   // pk[0 ~ 31] = seed[32~63] 로 A행렬 정보 저장
    Rq_vec_to_bytes(output + PKSEED_BYTES, &(pk->b));           // pk[32~351] = b vector를 byte 형식으로 저장
}

void load_from_string_pk(public_key* pk, const uint8_t* input) {
    memcpy(pk->seed, input, PKSEED_BYTES);
    genAx(pk->A, pk->seed);
    bytes_to_Rq_vec(&(pk->b), input + PKSEED_BYTES);
}




void indcpa_keypair(uint8_t pk[PUBLICKEY_BYTES],
    uint8_t sk[PKE_SECRETKEY_BYTES],
    uint8_t keypair_seed[32]) {
    public_key pk_tmp;
    secret_key sk_tmp;
    memset(&pk_tmp, 0, sizeof(public_key));
    memset(&sk_tmp, 0, sizeof(secret_key));

    uint8_t seed[CRYPTO_BYTES + PKSEED_BYTES] = { 0 };
    randombytes(seed, CRYPTO_BYTES);                            // seed[0~31] 에 대해 random 값 생성
	memcpy(keypair_seed, seed, 32);


#if CRYPTO_BYTES + PKSEED_BYTES != 64
#error "This implementation assumes CRYPTO_BYTES + PKSEED_BYTES to be 64"
#endif
    sha3_512(seed, seed, CRYPTO_BYTES);                         // 위에서 생성한 random값을 통해 seed[0~63] 생성

    genSx_vec(&sk_tmp, seed);                                   // 생성한 seed[0~31]을 통해 비밀값 s 생성

    memcpy(&pk_tmp.seed, seed + CRYPTO_BYTES, PKSEED_BYTES);    // pk_tmp.seed에에 생성한 seed[32~63]을 저장
    genPubkey(&pk_tmp, &sk_tmp, seed);                          // seed[32~63]을 통해 A를 생성, 생성한 s와 결합하여 b = -As + e를 생성

    memset(pk, 0, PUBLICKEY_BYTES);
    memset(sk, 0, PKE_SECRETKEY_BYTES);
    save_to_string_pk(pk, &pk_tmp);                             // pk = A seed(seed[32~63]) | b  로 저장
    save_to_string_sk(sk, &sk_tmp);                             // sk = s (save_string 의 결과로 sk는 1, -1을 2bit로 저장하기 때문에, 1 -> 01, -1 -> 11, 0 -> 00 으로 저장)
}

void indcpa_enc(uint8_t ctxt[CIPHERTEXT_BYTES],
    const uint8_t pk[PUBLICKEY_BYTES],
    const uint8_t mu[DELTA_BYTES],
    const uint8_t seed[DELTA_BYTES]) {

    uint8_t seed_r[DELTA_BYTES] = { 0 };
    public_key pk_tmp;
    load_from_string_pk(&pk_tmp, pk);           // pk_tmp에 A 행렬 seed, A행렬, b vector 를 저장

    // Compute a vector r = hwt(delta, H'(pk))
    polyvec r;
    memset(&r, 0, sizeof(polyvec));

    if (seed == NULL)
        randombytes(seed_r, DELTA_BYTES);           // enc_kem 과정에서 생성한 random seed가 없으면 random 값을 생성해서 사용
    else
        cmov(seed_r, seed, DELTA_BYTES, 1);         // 있다면 그 값을 그대로 가져옴

    genRx_vec(&r, seed_r);                          // seed를 통해 r vector 생성

    // Compute c1(x), c2(x)
    ciphertext ctxt_tmp;
    memset(&ctxt_tmp, 0, sizeof(ciphertext));
    computeC1(&(ctxt_tmp.c1), pk_tmp.A, &r);        // p/q(Ar)
    computeC2(&(ctxt_tmp.c2), mu, &pk_tmp.b, &r);   // p'/q * (br) + p'/t * mu

    save_to_string(ctxt, &ctxt_tmp);    // c1, c2 를 byte 형식으로 변경
}

void indcpa_dec(uint8_t delta[DELTA_BYTES],
    const uint8_t sk[PKE_SECRETKEY_BYTES],
    const uint8_t ctxt[CIPHERTEXT_BYTES]) {
    poly delta_temp;
    polyvec c1_temp;

    secret_key sk_tmp;
    memset(&sk_tmp, 0, sizeof(secret_key));
    load_from_string_sk(&sk_tmp, sk);                   // byte 형태의 sk를 다항식 형태로 변경

    ciphertext ctxt_tmp;
    load_from_string(&ctxt_tmp, ctxt);                  // byte 형태의 c1, c2를 다항식 형태로 변경

    unsigned int i, j;
    c1_temp = ctxt_tmp.c1;                              // c1을 temp에 저장
    delta_temp = ctxt_tmp.c2;                           // c2를 temp에 저장
    for (i = 0; i < LWE_N; ++i)
        delta_temp.coeffs[i] <<= _16_LOG_P2;            // c2를 1111 1000 0000 0000 으로 상위 bit에 저장
    for (i = 0; i < MODULE_RANK; ++i)
        for (j = 0; j < LWE_N; ++j)
            c1_temp.vec[i].coeffs[j] <<= _16_LOG_P;     // c1을 1111 1111 0000 0000 으로 상위 bit에 저장
    // -> 이는 rounding을 진행할 때 bit 연산으로 진행하기 위함

// Compute delta = (delta + c1^T * s)
    vec_vec_mult_add(&delta_temp, &c1_temp, &sk_tmp, _16_LOG_P);    // c2 + c1 * s 를 진행

    // Compute delta = 2/p * delta
    // 기존의 복호화는, t/p(c1*s) + t/p'(c2) -> t/p( c1 * s + p/p'(c2) )
    // 우리는 모든 값을 상위 bit로 저장하여 사용중 이었음
    // 즉, c1을 기준으로 했을 때, c2는 이미 p/p' 만큼 shift되어 있는 상태임
    // 따라서 t/p(c2 + c1 * s)는 사실 t/p( p/p'(c2) + c1 * s) 라고 볼 수 있음
    for (i = 0; i < LWE_N; ++i) {                       // t/p * (c2 + c1 * s)     
        delta_temp.coeffs[i] += DEC_ADD;                // p/p'(c2) + c1 * s + 2^15                 (반올림 기준값 0100 0000 0000 0000 을 더해주고)
        delta_temp.coeffs[i] >>= _16_LOG_T;             // (p/p'(c2) + c1 * s + 2^15)/2^16          -> t bit 만큼을 남길거니깐 언제나 이렇게 decryption 가능
        delta_temp.coeffs[i] &= 0x01;                   // 마지막 bit 만 가져오기
    }   // 결국 t/p(c2 + c1 * s)를 통해 t/p( p/p'(c2) + c1 * s) 을 계산

    // Set delta
    memset(delta, 0, DELTA_BYTES);
    for (i = 0; i < DELTA_BYTES; ++i) {
        for (j = 0; j < 8; ++j) {
            delta[i] ^= ((uint8_t)(delta_temp.coeffs[8 * i + j]) << j); // 결과값 delta를 기존 모양대로 저장
        }
    }
}


int crypto_kem_keypair(uint8_t* pk, uint8_t* sk, uint8_t* keypair_seed, uint8_t * rejection_seed) {
    indcpa_keypair(pk, sk, keypair_seed);                             // PKE keygen 스킴을 통해 pk, sk 생성
    randombytes(rejection_seed, T_BYTES);
    memcpy(sk + PKE_SECRETKEY_BYTES, rejection_seed, T_BYTES);
    //randombytes(sk + PKE_SECRETKEY_BYTES, T_BYTES);     // 암묵적 거부를 위한 random값 t 생성
    for (int i = 0; i < PUBLICKEY_BYTES; i++)
        sk[i + PKE_SECRETKEY_BYTES + T_BYTES] = pk[i];  // sk = sk | t | pk 로 저장
    return 0;
}

int crypto_kem_enc(uint8_t* ctxt, uint8_t* ss, const uint8_t* pk, uint8_t* mu_seed) {
    uint8_t mu[DELTA_BYTES] = { 0 }; // shared secret and seed
    uint8_t buf[DELTA_BYTES + CRYPTO_BYTES] = { 0 };

    randombytes(mu, DELTA_BYTES);                                   // shared secret key의 seed값인 mu 생성
	memcpy(mu_seed, mu, 32);

    hash_h(buf, pk, PUBLICKEY_BYTES);                               // H(pk)   
    hash_g(buf, DELTA_BYTES + CRYPTO_BYTES, mu, DELTA_BYTES, buf,   // seed | ssk = G(mu, H(pk))
        SHA3_256_HashSize);

    memset(ss, 0, CRYPTO_BYTES);
    indcpa_enc(ctxt, pk, mu, buf);                                  // pke 스킴의 encryption 과정을 통해 mu를 encryption
    cmov(ss, buf + DELTA_BYTES, CRYPTO_BYTES, 1);                   // ss에 G(mu, H(pk))[32~63] 을 저장

    return 0;
}


// ctxt : c1 | c2  ,  sk : sk | t | pk
int crypto_kem_dec(uint8_t* ss, const uint8_t* ctxt, const uint8_t* sk) {
    uint8_t mu[DELTA_BYTES] = { 0 };
    uint8_t buf[DELTA_BYTES + CRYPTO_BYTES] = { 0 }; // shared secret and seed
    uint8_t buf_tmp[DELTA_BYTES + CRYPTO_BYTES] = { 0 };
    uint8_t hash_res[SHA3_256_HashSize] = { 0 };
    const uint8_t* pk = sk + PKE_SECRETKEY_BYTES + T_BYTES;

    indcpa_dec(mu, sk, ctxt);                                           // c1, c2, s를 통해 mu(ssk seed) 복원
    hash_h(hash_res, pk, PUBLICKEY_BYTES);                              // H(pk)
    hash_g(buf, DELTA_BYTES + CRYPTO_BYTES, mu, DELTA_BYTES, hash_res,  // seed | SSK = G(mu, H(pk))
        SHA3_256_HashSize);

    uint8_t ctxt_temp[CIPHERTEXT_BYTES] = { 0 };
    indcpa_enc(ctxt_temp, pk, mu, buf);                                 // pk, 복호화한 mu, 이를 통해 생성한 r seed로 c1', c2'을 생성


    int fail = verify(ctxt, ctxt_temp, CIPHERTEXT_BYTES);               // verify 성공시 0, 실패시 1을 fail에 저장

    hash_h(hash_res, ctxt, CIPHERTEXT_BYTES);                           // H(c1,c2)
    hash_g(buf_tmp, DELTA_BYTES + CRYPTO_BYTES,                         // G(d | H(ct))를 통해 암묵적 거부를 위한 SSK' 생성
        sk + PKE_SECRETKEY_BYTES, T_BYTES, hash_res,
        SHA3_256_HashSize);

    memset(ss, 0, CRYPTO_BYTES);
    cmov(buf + DELTA_BYTES, buf_tmp + DELTA_BYTES, CRYPTO_BYTES, fail); // SSK를 저장하고 있는 buf[32~63]에 verify가 성공했다면 그대로, 실패했다면 SSK'을 저장
    cmov(ss, buf + DELTA_BYTES, CRYPTO_BYTES, 1);                       // 저장한 SSK를 ss에 저장
    return 0;
}


int main(int argc, const char** argv) {
    char fn_req[64], fn_rsp[64];
    FILE* fp_req, * fp_rsp, *real_seed_fp;
    unsigned char seed[48];
    unsigned char entropy_input[48];
    unsigned char ct[CRYPTO_CIPHERTEXTBYTES], ss[CRYPTO_BYTES],
        ss1[CRYPTO_BYTES];
    int count;
    int done;
    unsigned char pk[CRYPTO_PUBLICKEYBYTES], sk[CRYPTO_KEM_SECRETKEYBYTES];
    int ret_val;

    sprintf(fn_rsp, "sjchoi change easy seed SMAUG T%d PQCkemKAT_%u.rsp", SMAUG_MODE, CRYPTO_KEM_SECRETKEYBYTES);
    if ((fp_rsp = fopen(fn_rsp, "w")) == NULL) {
        printf("Couldn't open <%s> for write\n", fn_rsp);
        return KAT_FILE_OPEN_ERROR;
    }

    sprintf(fn_req, "PQCkemKAT_%u.req", CRYPTO_KEM_SECRETKEYBYTES);
    if (argc == 1 || strcmp("--disable-seed-gen", argv[1]) != 0) {
        // Create the REQUEST file
        if ((fp_req = fopen(fn_req, "w")) == NULL) {
            printf("Couldn't open <%s> for write\n", fn_req);
            return KAT_FILE_OPEN_ERROR;
        }

        for (int i = 0; i < 48; i++)
            entropy_input[i] = i;

        randombytes_init(entropy_input, NULL, 256);
        for (int i = 0; i < 100; i++) {
            fprintf(fp_req, "count = %d\n", i);
            randombytes(seed, 48);
            fprintBstr(fp_req, "seed = ", seed, 48);
			fprintf(fp_req, "keypair_seed =\n");
            fprintf(fp_req, "rejection_seed =\n");
            fprintf(fp_req, "pk =\n");
            fprintf(fp_req, "sk =\n");
			fprintf(fp_req, "mu_seed =\n");
            fprintf(fp_req, "ct =\n");
            fprintf(fp_req, "ss =\n\n");
        }
        fclose(fp_req);
    }
    else {
        printf("Skip seed generation.\n");
    }

    // Create the RESPONSE file based on what's in the REQUEST file
    if ((fp_req = fopen(fn_req, "r")) == NULL) {
        printf("Couldn't open <%s> for read\n", fn_req);
        return KAT_FILE_OPEN_ERROR;
    }
    if(SMAUG_MODE == 1)
        fprintf(fp_rsp, "# %s\n\n", "sjchoi - change easy seed SMAUG-T1");
    else if(SMAUG_MODE == 3)
        fprintf(fp_rsp, "# %s\n\n", "sjchoi - change easy seed SMAUG-T3");
    else if(SMAUG_MODE == 5)
		fprintf(fp_rsp, "# %s\n\n", "sjchoi - change easy seed SMAUG-T5");
    if(MUL_MOD == 0)
        fprintf(fp_rsp, "# %s\n\n", "MUL_MOD = 0 : TC4-Karatsuba");
    else if(MUL_MOD == 1)
        fprintf(fp_rsp, "# %s\n\n", "MUL_MOD = 1 : NTT");

    done = 0;
    do {
        if (FindMarker(fp_req, "count = ")) {
            if (fscanf(fp_req, "%d", &count) == -1) {
                printf("Couldn't read <%s>\n", fn_req);
                return KAT_FILE_OPEN_ERROR;
            }
        }

        else {
            done = 1;
            break;
        }
        fprintf(fp_rsp, "count = %d\n", count);

        if (!ReadHex(fp_req, seed, 48, "seed = ")) {
            printf("ERROR: unable to read 'seed' from <%s>\n", fn_req);
            return KAT_DATA_ERROR;
        }

        fprintBstr(fp_rsp, "seed = ", seed, 48);

        // Generate the public/private keypair from the seed
        randombytes_init(seed, NULL, 256);
        uint8_t keypair_seed[32];
        uint8_t rejection_seed[32];
        if ((ret_val = crypto_kem_keypair(pk, sk, keypair_seed, rejection_seed)) != 0) {
            printf("crypto_kem_keypair returned <%d>\n", ret_val);
            return KAT_CRYPTO_FAILURE;
        }
        
        fprintBstr(fp_rsp, "keypair_seed = ", keypair_seed, 32);
        fprintBstr(fp_rsp, "rejection_seed = ", rejection_seed, 32);
        fprintBstr(fp_rsp, "pk = ", pk, CRYPTO_PUBLICKEYBYTES);
        fprintBstr(fp_rsp, "sk = ", sk, CRYPTO_KEM_SECRETKEYBYTES);

        uint8_t mu_seed[32];
        if ((ret_val = crypto_kem_enc(ct, ss, pk, mu_seed)) != 0) {
            printf("crypto_kem_enc returned <%d>\n", ret_val);
            return KAT_CRYPTO_FAILURE;
        }
        fprintBstr(fp_rsp, "mu_seed = ", mu_seed, 32);
        fprintBstr(fp_rsp, "ct = ", ct, CRYPTO_CIPHERTEXTBYTES);
        fprintBstr(fp_rsp, "ss = ", ss, CRYPTO_BYTES);

        fprintf(fp_rsp, "\n");

        if ((ret_val = crypto_kem_dec(ss1, ct, sk)) != 0) {
            printf("crypto_kem_dec returned <%d>\n", ret_val);
            return KAT_CRYPTO_FAILURE;
        }

        if (memcmp(ss, ss1, CRYPTO_BYTES)) {
            printf("crypto_kem_dec returned bad 'ss' value\n");
            return KAT_CRYPTO_FAILURE;
        }
    } while (!done);

    fclose(fp_req);
    fclose(fp_rsp);

    return KAT_SUCCESS;
}
